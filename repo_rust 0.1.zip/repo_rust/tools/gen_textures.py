#!/usr/bin/env python3
"""Génère les textures du jeu : 8 matériaux, chacun en couleur + carte de relief (normal map).

100 % procédural et original (aucune image tirée du vrai jeu). Toutes les textures se raccordent
(« tileable »), en 256x256.   Usage :  python tools/gen_textures.py   (nécessite numpy et Pillow)
"""
import os
import numpy as np
from PIL import Image

N = 256
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "textures")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(2024)


def norm(a):
    a = a - a.min()
    return a / (a.max() + 1e-9)


def fnoise(beta=2.0, aniso=(1.0, 1.0), seed=None):
    """Bruit fractal périodique (donc raccordable) : spectre en 1/f^beta, valeur dans [0,1]."""
    r = np.random.default_rng(seed) if seed is not None else rng
    fy = np.fft.fftfreq(N)[:, None] * aniso[0]
    fx = np.fft.fftfreq(N)[None, :] * aniso[1]
    f = np.sqrt(fx**2 + fy**2)
    f[0, 0] = 1.0
    spec = (r.normal(size=(N, N)) + 1j * r.normal(size=(N, N))) / f ** (beta / 2)
    spec[0, 0] = 0
    return norm(np.real(np.fft.ifft2(spec)))


def grid(cell_y, cell_x):
    y, x = np.mgrid[0:N, 0:N]
    return y, x, (y % cell_y), (x % cell_x)


def to_normal(h, strength=3.0):
    """Hauteur -> carte de relief (convention OpenGL, comme Bevy)."""
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * 0.5
    dy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * 0.5
    nx, ny, nz = -dx * strength * N / 64, dy * strength * N / 64, np.ones_like(h)
    ln = np.sqrt(nx**2 + ny**2 + nz**2)
    return np.stack([nx / ln, ny / ln, nz / ln], -1) * 0.5 + 0.5


def save(name, color, height, strength=3.0):
    c = np.clip(color, 0, 1)
    Image.fromarray((c * 255).astype(np.uint8)).save(os.path.join(OUT, f"{name}.png"), optimize=True)
    n = to_normal(height, strength)
    Image.fromarray((np.clip(n, 0, 1) * 255).astype(np.uint8)).save(os.path.join(OUT, f"{name}_n.png"), optimize=True)
    print(f"{name}.png  {name}_n.png")


def gray(v, tint=(1, 1, 1)):
    return np.stack([v * tint[0], v * tint[1], v * tint[2]], -1)


# --- Béton : grain fin, taches, petits trous --------------------------------------
h = fnoise(2.2) * 0.6 + fnoise(1.0) * 0.4
pits = (fnoise(0.6) > 0.93).astype(float)
v = 0.55 + 0.25 * (fnoise(3.0) - 0.5) + 0.18 * (h - 0.5) - 0.25 * pits
save("concrete", gray(v, (1.0, 1.0, 0.97)), h - 0.4 * pits, 2.5)

# --- Plâtre / peinture : presque lisse, coulures verticales ---------------------------
streak = fnoise(2.5, aniso=(1.0, 0.06))
v = 0.82 + 0.12 * (fnoise(3.0) - 0.5) - 0.18 * (streak - 0.5) ** 2 * 4
h = fnoise(1.5) * 0.3 + fnoise(0.8) * 0.2
save("plaster", gray(v), h, 1.2)

# --- Brique : joints de mortier, teinte variable par brique ---------------------------
bh, bw = 32, 64
y, x, ry, rx = grid(bh, bw)
row = y // bh
xs = (x + (row % 2) * (bw // 2)) % bw
mortar = (ry < 4) | (xs < 4)
brick_id = (row * 7 + ((x + (row % 2) * (bw // 2)) // bw) * 13) % 11
tone = 0.75 + 0.25 * (brick_id / 10.0)
grain = fnoise(1.2)
col = np.stack([0.62 * tone, 0.30 * tone, 0.22 * tone], -1) * (0.8 + 0.4 * grain[..., None])
col[mortar] = gray(0.62 + 0.12 * grain)[mortar]
h = np.where(mortar, 0.0, 0.7 + 0.3 * grain)
save("brick", col, h, 4.0)

# --- Carrelage : dalles de 64 px, joints, usure ----------------------------------------
ts = 64
y, x, ry, rx = grid(ts, ts)
grout = (ry < 3) | (rx < 3)
tid = ((y // ts) * 5 + (x // ts) * 3) % 7
tone = 0.80 + 0.14 * (tid / 6.0)
wear = fnoise(1.6)
v = tone * (0.9 + 0.12 * wear) - 0.12 * (fnoise(0.5) > 0.92)
col = gray(v, (1.0, 1.0, 1.0))
col[grout] = gray(0.36 + 0.06 * wear)[grout]
h = np.where(grout, 0.0, 0.8 + 0.1 * wear)
save("tile", col, h, 3.0)

# --- Bois : planches horizontales, veines, joints ------------------------------------------
ph = 32
y, x, ry, rx = grid(ph, N)
pid = y // ph
shift = (pid * 53) % N
xx = (x + shift) % N
veins = fnoise(2.8, aniso=(0.04, 1.0), seed=7)
fine = fnoise(1.4, aniso=(0.1, 1.0), seed=8)
base = 0.45 + 0.07 * ((pid * 5) % 4)
v = base * (0.75 + 0.5 * veins) + 0.08 * (fine - 0.5)
seam = ry < 2
col = np.stack([v * 0.95, v * 0.68, v * 0.42], -1)
col[seam] = col[seam] * 0.25
knots = fnoise(0.7, seed=9) > 0.965
col[knots] *= 0.55
h = 0.5 * veins + 0.3 * fine - np.where(seam, 0.6, 0)
save("wood", col, h, 2.0)

# --- Métal : plaques rivetées, rayures brossées ---------------------------------------------------
pl = 128
y, x, ry, rx = grid(pl, pl)
seam = (ry < 3) | (rx < 3)
brushed = fnoise(2.6, aniso=(0.05, 1.0), seed=11)
rivet = np.zeros((N, N))
for cy in (10, pl - 10):
    for cx in (10, pl - 10):
        for oy in (0, pl):
            for ox in (0, pl):
                d = np.sqrt((y - (cy + oy)) ** 2 + (x - (cx + ox)) ** 2)
                rivet = np.maximum(rivet, np.clip(1 - d / 4.5, 0, 1))
rust = fnoise(1.8, seed=12) > 0.72
v = 0.5 + 0.2 * (brushed - 0.5) + 0.2 * rivet
col = gray(v, (0.9, 0.95, 1.0))
col[seam] *= 0.45
col[rust] = col[rust] * np.array([1.0, 0.62, 0.4])
h = 0.3 * brushed + 0.7 * rivet - np.where(seam, 0.5, 0)
save("metal", col, h, 3.0)

# --- Moquette : fibres serrées -----------------------------------------------------------------------
fib = fnoise(0.3, seed=21)
weave = 0.5 + 0.5 * np.sin(np.arange(N)[None, :] * 2 * np.pi / 4) * np.sin(np.arange(N)[:, None] * 2 * np.pi / 4)
v = 0.62 + 0.3 * (fib - 0.5) + 0.08 * weave + 0.1 * (fnoise(3.0, seed=22) - 0.5)
save("carpet", gray(v), 0.6 * fib + 0.4 * weave, 1.5)

# --- Dalles de plafond : grille 4x4, petits trous -----------------------------------------------------
cs = 64
y, x, ry, rx = grid(cs, cs)
frame = (ry < 3) | (rx < 3)
holes = (fnoise(0.2, seed=31) > 0.82) & ~frame
v = 0.84 + 0.08 * (fnoise(2.5, seed=32) - 0.5)
v = np.where(holes, v - 0.28, v)
col = gray(v, (1.0, 1.0, 0.96))
col[frame] = 0.5
h = np.where(frame, 0.0, 0.8) - np.where(holes, 0.4, 0)
save("ceiling", col, h, 3.0)

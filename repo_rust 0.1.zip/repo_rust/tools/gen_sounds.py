#!/usr/bin/env python3
"""Génère les effets sonores du jeu (synthèse 100 % originale, aucun son tiré du vrai jeu).

Usage :  python tools/gen_sounds.py   (nécessite numpy)
Les fichiers sont écrits dans assets/sounds/.
"""
import os
import wave
import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(1234)


def t(dur):
    return np.arange(int(SR * dur)) / SR


def noise(dur):
    return rng.uniform(-1, 1, int(SR * dur))


def filt(x, lo=None, hi=None):
    """Filtre passe-bande par FFT (lo = coupe en dessous, hi = coupe au-dessus), en Hz."""
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    mask = np.ones_like(f)
    if lo:
        mask *= f >= lo
    if hi:
        mask *= f <= hi
    return np.fft.irfft(spec * mask, len(x))


def env(x, attack=0.003, decay=6.0):
    n = len(x)
    tt = np.arange(n) / SR
    e = np.exp(-decay * tt)
    a = max(1, int(SR * attack))
    e[:a] *= np.linspace(0, 1, a)
    return x * e


def sine(freq, dur, phase=0.0):
    return np.sin(2 * np.pi * freq * t(dur) + phase)


def sweep(f0, f1, dur):
    tt = t(dur)
    f = f0 + (f1 - f0) * (tt / dur)
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[: len(p)] += p
    return out


def save(name, x, peak=0.8):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    data = (x * 32767).astype(np.int16)
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    print(f"{name}.wav  {len(x) / SR:.2f}s")


os.makedirs(OUT, exist_ok=True)

# --- Pas, saut, atterrissage --------------------------------------------------
save("step1", mix(env(filt(noise(0.14), 80, 900), decay=28), env(sine(75, 0.14), decay=30) * 0.8), 0.6)
save("step2", mix(env(filt(noise(0.14), 100, 1200), decay=30), env(sine(90, 0.14), decay=32) * 0.7), 0.6)
save("jump", env(filt(noise(0.22), 300, 2500), attack=0.05, decay=10), 0.5)
save("land", mix(env(sine(60, 0.3), decay=14), env(filt(noise(0.3), 40, 700), decay=16)), 0.8)

# --- Impacts ---------------------------------------------------------------------
save("impact_soft", mix(env(sweep(160, 90, 0.2), decay=22), env(filt(noise(0.2), 100, 1500), decay=30) * 0.6), 0.7)
save(
    "impact_hard",
    mix(
        env(sweep(110, 45, 0.45), decay=11),
        env(filt(noise(0.45), 60, 3000), decay=14) * 0.9,
        env(filt(noise(0.05), 1500, 6000), decay=80) * 0.5,
    ),
    0.9,
)

# Verre qui se brise : éclat bruité + tintements aigus décalés.
glass = env(filt(noise(0.7), 2500, 9000), decay=7) * 0.7
for k in range(14):
    f = rng.uniform(2200, 7200)
    start = int(rng.uniform(0, 0.35) * SR)
    ring = env(sine(f, 0.5), decay=rng.uniform(8, 20)) * rng.uniform(0.2, 0.5)
    glass[start : start + len(ring)] += ring[: len(glass) - start]
save("glass", glass, 0.85)

# --- Interactions -------------------------------------------------------------
save("grab", mix(env(sweep(180, 320, 0.14), decay=18), env(filt(noise(0.1), 800, 4000), decay=40) * 0.3), 0.5)
save("release", mix(env(sweep(320, 160, 0.12), decay=20), env(filt(noise(0.08), 600, 3000), decay=40) * 0.25), 0.45)
save("throw", env(filt(noise(0.3), 200, 3500), attack=0.08, decay=9), 0.6)
save("flashlight", env(filt(noise(0.04), 1500, 8000), attack=0.0005, decay=90), 0.6)
save("error", env(sweep(110, 90, 0.25), decay=7) * np.sign(sine(60, 0.25)) * 0.6, 0.5)
save("ding", mix(env(sine(880, 1.4), decay=3.2), env(sine(1320, 1.4), decay=4.0) * 0.5, env(sine(1760, 1.4), decay=5.5) * 0.3), 0.7)
save("buy", mix(env(sine(660, 0.5), decay=7), np.concatenate([np.zeros(int(0.09 * SR)), env(sine(990, 0.5), decay=7)])), 0.6)
save("beep", env(sine(1050, 0.16), attack=0.002, decay=14) + 0.4 * env(sine(2100, 0.16), attack=0.002, decay=20), 0.6)
save("heal", mix(env(sweep(300, 700, 0.5), attack=0.05, decay=4) * 0.6, env(sine(900, 0.6), attack=0.1, decay=5) * 0.4), 0.5)

# --- Joueur : douleur, mort, cœur ---------------------------------------------
save("hurt", mix(env(sweep(260, 130, 0.35), decay=9), env(filt(noise(0.35), 200, 2500), decay=12) * 0.7), 0.85)
save("death", mix(env(sweep(220, 40, 1.6), attack=0.02, decay=2.2), env(filt(noise(1.6), 50, 800), decay=3) * 0.6), 0.9)
beat = env(sine(55, 0.18), decay=22)
heart = np.zeros(int(SR * 0.6))
heart[: len(beat)] += beat
heart[int(0.22 * SR) : int(0.22 * SR) + len(beat)] += beat * 0.7
save("heartbeat", heart, 0.9)

# --- Monstres -----------------------------------------------------------------------
tt = t(0.9)
growl = np.sign(np.sin(2 * np.pi * (70 + 12 * np.sin(2 * np.pi * 5 * tt)) * tt)) * 0.4
growl = filt(growl, 50, 700) * (0.6 + 0.4 * np.sin(2 * np.pi * 22 * tt))
growl = mix(growl, filt(noise(0.9), 200, 1600) * 0.25)
growl *= np.minimum(1, tt / 0.12) * np.minimum(1, (0.9 - tt) / 0.3)
save("enemy_alert", growl, 0.9)
save("enemy_attack", mix(env(filt(noise(0.25), 1200, 7000), attack=0.01, decay=14) * 0.8, env(sweep(140, 60, 0.25), decay=14)), 0.9)
save("enemy_die", mix(env(sweep(200, 50, 0.7), decay=5), env(filt(noise(0.7), 100, 1500), decay=7) * 0.5), 0.8)

# --- Ambiance : nappe grave en boucle (12 s, raccord sans coupure) ------------------
DUR = 12.0
n = int(SR * DUR)
tt = np.arange(n) / SR
amb = (
    np.sin(2 * np.pi * 55 * tt) * 0.5
    + np.sin(2 * np.pi * 82.5 * tt + 1.0) * 0.25
    + np.sin(2 * np.pi * 110 * tt + 2.0) * 0.15
    + np.sin(2 * np.pi * 164 * tt) * 0.05 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.25 * tt))
)
fade = int(SR * 1.5)
wind = filt(noise(DUR + 1.5), 60, 500)
w = np.linspace(0, 1, fade)
loop_noise = wind[:n].copy()
loop_noise[:fade] = wind[:fade] * w + wind[n : n + fade] * (1 - w)
loop_noise *= 0.5 + 0.5 * np.sin(2 * np.pi * (1 / 6.0) * tt + 0.5)  # 2 cycles sur 12 s : raccord garanti
amb = amb + loop_noise * 0.6
save("ambience", amb, 0.5)

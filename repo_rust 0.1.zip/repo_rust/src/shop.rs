//! Station-service : entre deux niveaux, on dépense son surplus en améliorations.

use bevy::prelude::*;
use bevy::text::FontSize;

use crate::common::*;
use crate::game::{GameState, Run};
use crate::player::Player;

const PACK_PRICE: f32 = 1200.0;
const UPGRADE_KEYS: [KeyCode; 5] =
    [KeyCode::Digit1, KeyCode::Digit2, KeyCode::Digit3, KeyCode::Digit4, KeyCode::Digit5];

#[derive(Component)]
struct ShopUi;

#[derive(Component)]
struct ShopText;

pub struct ShopPlugin;

impl Plugin for ShopPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(GameState::Shop), spawn_shop)
            .add_systems(OnExit(GameState::Shop), despawn_shop)
            .add_systems(Update, shop_input.run_if(in_state(GameState::Shop)));
    }
}

fn upgrade_price(level: u32) -> f32 {
    2000.0 + 1500.0 * level as f32
}

fn spawn_shop(mut commands: Commands) {
    commands
        .spawn((
            ShopUi,
            Node {
                position_type: PositionType::Absolute,
                width: Val::Percent(100.0),
                height: Val::Percent(100.0),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(Color::srgba(0.02, 0.03, 0.05, 0.96)),
        ))
        .with_children(|root| {
            root.spawn((
                ShopText,
                Text::new(""),
                TextFont { font_size: FontSize::Px(26.0), ..default() },
                TextColor(Color::srgb(0.85, 0.95, 0.85)),
            ));
        });
}

fn despawn_shop(mut commands: Commands, ui: Query<Entity, With<ShopUi>>) {
    for e in &ui {
        commands.entity(e).despawn();
    }
}

fn shop_input(
    keys: Res<ButtonInput<KeyCode>>,
    mut run: ResMut<Run>,
    mut health: Single<&mut Health, With<Player>>,
    mut text: Single<&mut Text, With<ShopText>>,
    mut next: ResMut<NextState<GameState>>,
    mut sfx: MessageWriter<PlaySfx>,
) {
    let prices = [
        upgrade_price(run.health_lvl),
        upgrade_price(run.stamina_lvl),
        upgrade_price(run.strength_lvl),
        upgrade_price(run.speed_lvl),
        PACK_PRICE,
    ];

    if let Some(i) = UPGRADE_KEYS.iter().position(|k| keys.just_pressed(*k)) {
        if run.money >= prices[i] {
            run.money -= prices[i];
            match i {
                0 => {
                    run.health_lvl += 1;
                    health.max += 20.0;
                    health.current += 20.0;
                }
                1 => run.stamina_lvl += 1,
                2 => run.strength_lvl += 1,
                3 => run.speed_lvl += 1,
                _ => run.packs += 1,
            }
            sfx.write(PlaySfx::flat(Sfx::Buy, 0.8));
        } else {
            sfx.write(PlaySfx::flat(Sfx::Error, 0.6));
        }
    }

    if keys.just_pressed(KeyCode::Enter) {
        run.level += 1;
        next.set(GameState::Playing);
    }

    text.0 = format!(
        "=== STATION-SERVICE ===\n\n\
         Niveau {} terminé.   Surplus : {:.0} $\n\
         Santé : {:.0} / {:.0} PV  (elle ne remonte pas toute seule)\n\n\
         [1] Santé max +20          niv. {}   {:.0} $\n\
         [2] Endurance max +20      niv. {}   {:.0} $\n\
         [3] Force (+25 %)          niv. {}   {:.0} $\n\
         [4] Vitesse (+7 %)         niv. {}   {:.0} $\n\
         [5] Pack de soin (+40 PV)  possédés : {}   {:.0} $\n\n\
         [Entrée] Niveau suivant",
        run.level,
        run.money,
        health.current,
        health.max,
        run.health_lvl,
        prices[0],
        run.stamina_lvl,
        prices[1],
        run.strength_lvl,
        prices[2],
        run.speed_lvl,
        prices[3],
        run.packs,
        prices[4],
    );
}

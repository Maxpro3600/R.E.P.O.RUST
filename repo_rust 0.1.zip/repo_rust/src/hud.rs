//! Interface : objectif, barres de santé et d'endurance, interactions, messages, écran de mort.

use bevy::prelude::*;
use bevy::text::FontSize;

use crate::combat::HurtFlash;
use crate::common::*;
use crate::game::{GameState, Run};
use crate::grab::{Held, Looking};
use crate::extraction::{ExtractionPoint, PointState};
use crate::interact::Interactable;
use crate::player::{Player, Stamina};
use crate::valuables::Valuable;

/// Racine d'un élément d'interface de jeu (masquée dans les menus).
#[derive(Component)]
struct HudRoot;
#[derive(Component)]
struct InfoText;
#[derive(Component)]
struct StatsText;
#[derive(Component)]
struct PromptText;
#[derive(Component)]
struct ToastText;
#[derive(Component)]
struct HealthFill;
#[derive(Component)]
struct StaminaFill;
#[derive(Component)]
struct FlashOverlay;
#[derive(Component)]
struct DeathUi;

#[derive(Resource, Default)]
struct Toasts(Vec<(String, f32)>);

pub struct HudPlugin;

impl Plugin for HudPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<Toasts>()
            .add_systems(Startup, setup_hud)
            .add_systems(OnEnter(GameState::Dead), spawn_death_ui)
            .add_systems(OnExit(GameState::Dead), despawn_death_ui)
            .add_systems(
                Update,
                (update_info, update_bars, update_prompt, update_toasts, update_flash),
            )
            .add_systems(Update, hud_visibility.run_if(state_changed::<GameState>));
    }
}

fn font(size: f32) -> TextFont {
    TextFont { font_size: FontSize::Px(size), ..default() }
}

fn bar(parent: &mut ChildSpawnerCommands, fill: impl Bundle, color: Color) {
    parent
        .spawn((
            Node { width: Val::Px(240.0), height: Val::Px(14.0), ..default() },
            BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 0.55)),
        ))
        .with_children(|b| {
            b.spawn((
                fill,
                Node { width: Val::Percent(100.0), height: Val::Percent(100.0), ..default() },
                BackgroundColor(color),
            ));
        });
}

fn setup_hud(mut commands: Commands) {
    // Flash rouge (dégâts, santé basse), sous le reste de l'interface.
    commands.spawn((
        HudRoot,
        FlashOverlay,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            ..default()
        },
        BackgroundColor(Color::srgba(0.7, 0.0, 0.0, 0.0)),
    ));

    // Objectif et argent, en haut à gauche.
    commands.spawn((
        HudRoot,
        InfoText,
        Text::new(""),
        font(22.0),
        TextColor(Color::WHITE),
        Node { position_type: PositionType::Absolute, top: Val::Px(12.0), left: Val::Px(12.0), ..default() },
    ));

    // Messages, en haut à droite.
    commands.spawn((
        HudRoot,
        ToastText,
        Text::new(""),
        font(18.0),
        TextColor(Color::srgb(1.0, 0.9, 0.6)),
        Node { position_type: PositionType::Absolute, top: Val::Px(12.0), right: Val::Px(12.0), ..default() },
    ));

    // Barres de santé et d'endurance, en bas à gauche.
    commands
        .spawn((HudRoot, Node {
            position_type: PositionType::Absolute,
            bottom: Val::Px(40.0),
            left: Val::Px(12.0),
            flex_direction: FlexDirection::Column,
            row_gap: Val::Px(4.0),
            ..default()
        }))
        .with_children(|col| {
            col.spawn((StatsText, Text::new(""), font(16.0), TextColor(Color::WHITE)));
            bar(col, HealthFill, Color::srgb(0.8, 0.15, 0.15));
            bar(col, StaminaFill, Color::srgb(0.9, 0.8, 0.2));
        });

    // Aide, tout en bas.
    commands.spawn((
        HudRoot,
        Text::new(
            "Clic : souris | Echap : liberer | WASD/ZQSD | Maj : courir | Ctrl/C : s'accroupir | Espace : sauter | F : lampe | Clic droit : attraper | Clic gauche : lancer | E : camion | H : soin | Echap : pause",
        ),
        font(14.0),
        TextColor(Color::srgba(1.0, 1.0, 1.0, 0.55)),
        Node { position_type: PositionType::Absolute, bottom: Val::Px(10.0), left: Val::Px(12.0), ..default() },
    ));

    // Réticule et message d'interaction, au centre.
    commands
        .spawn((HudRoot, Node {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            justify_content: JustifyContent::Center,
            align_items: AlignItems::Center,
            ..default()
        }))
        .with_children(|root| {
            root.spawn((
                Node {
                    width: Val::Px(6.0),
                    height: Val::Px(6.0),
                    border_radius: BorderRadius::MAX,
                    ..default()
                },
                BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.8)),
            ));
        });
    commands
        .spawn((HudRoot, Node {
            position_type: PositionType::Absolute,
            top: Val::Percent(56.0),
            width: Val::Percent(100.0),
            justify_content: JustifyContent::Center,
            ..default()
        }))
        .with_children(|root| {
            root.spawn((PromptText, Text::new(""), font(20.0), TextColor(Color::srgb(1.0, 0.95, 0.7))));
        });
}

/// L'interface de jeu n'apparaît qu'en jeu (et en pause), pas dans les menus ni à la boutique.
fn hud_visibility(state: Res<State<GameState>>, mut roots: Query<&mut Visibility, With<HudRoot>>) {
    let show = matches!(state.get(), GameState::Playing | GameState::Paused);
    for mut visibility in &mut roots {
        *visibility = if show { Visibility::Inherited } else { Visibility::Hidden };
    }
}

fn update_info(
    run: Res<Run>,
    points: Query<&ExtractionPoint>,
    mut text: Single<&mut Text, With<InfoText>>,
) {
    let remaining = run.extractions_total.saturating_sub(run.extractions_done);
    let mut lines = vec![
        format!("NIVEAU {}", run.level),
        format!("Extractions restantes : {} / {}", remaining, run.extractions_total),
    ];
    let mut sorted: Vec<&ExtractionPoint> = points.iter().collect();
    sorted.sort_by_key(|p| p.index);
    for p in sorted {
        let status = match p.state {
            PointState::Waiting => format!("{:.0} / {:.0} $", p.in_zone, p.goal),
            PointState::Extracting(left) => format!("EXTRACTION EN COURS... {:.0} s", left.ceil()),
            PointState::Done => "terminée".to_string(),
        };
        lines.push(format!("   Plateforme {} : {}", p.index + 1, status));
    }
    lines.push(format!("Butin extrait : {:.0} $    Surplus : {:.0} $", run.banked, run.money));
    if run.all_extracted() {
        lines.push("TOUT EST EXTRAIT : retourne au terminal du camion !".to_string());
    }
    text.0 = lines.join("\n");
}

fn update_bars(
    player: Single<(&Health, &Stamina), With<Player>>,
    run: Res<Run>,
    mut health_fill: Single<&mut Node, (With<HealthFill>, Without<StaminaFill>)>,
    mut stamina_fill: Single<&mut Node, (With<StaminaFill>, Without<HealthFill>)>,
    mut text: Single<&mut Text, With<StatsText>>,
) {
    let (health, stamina) = *player;
    health_fill.width = Val::Percent(health.fraction() * 100.0);
    stamina_fill.width = Val::Percent((stamina.current / stamina.max).clamp(0.0, 1.0) * 100.0);
    text.0 = format!(
        "PV {:.0}/{:.0}   Endurance {:.0}   Soins : {} [H]",
        health.current.max(0.0),
        health.max,
        stamina.current,
        run.packs
    );
}

fn update_prompt(
    looking: Res<Looking>,
    held: Res<Held>,
    run: Res<Run>,
    names: Query<(&Name, Option<&Valuable>)>,
    interactables: Query<&Interactable>,
    mut text: Single<&mut Text, With<PromptText>>,
) {
    let describe = |e: Entity| {
        names.get(e).ok().map(|(name, v)| match v {
            Some(v) => format!("{} - {:.0} $", name, v.value),
            None => name.to_string(),
        })
    };
    text.0 = if let Some(e) = held.entity {
        describe(e).map(|d| format!("{d}\n[Clic gauche] lancer")).unwrap_or_default()
    } else if let Some(e) = looking.grab {
        describe(e).map(|d| format!("{d}\n[Clic droit] attraper")).unwrap_or_default()
    } else if let Some(kind) = looking.interact.and_then(|e| interactables.get(e).ok()) {
        match kind {
            Interactable::Truck if run.all_extracted() => "[E] Partir avec le camion".to_string(),
            Interactable::Truck => format!(
                "Terminal du camion : il reste {} extraction(s)",
                run.extractions_total - run.extractions_done
            ),
        }
    } else {
        String::new()
    };
}

fn update_toasts(
    time: Res<Time>,
    mut messages: MessageReader<Toast>,
    mut toasts: ResMut<Toasts>,
    mut text: Single<&mut Text, With<ToastText>>,
) {
    for m in messages.read() {
        toasts.0.push((m.0.clone(), 5.0));
    }
    let dt = time.delta_secs();
    toasts.0.iter_mut().for_each(|t| t.1 -= dt);
    toasts.0.retain(|t| t.1 > 0.0);
    let excess = toasts.0.len().saturating_sub(6);
    toasts.0.drain(..excess);
    text.0 = toasts.0.iter().map(|t| t.0.as_str()).collect::<Vec<_>>().join("\n");
}

fn update_flash(
    time: Res<Time>,
    mut flash: ResMut<HurtFlash>,
    player: Single<&Health, With<Player>>,
    mut overlay: Single<&mut BackgroundColor, With<FlashOverlay>>,
) {
    flash.0 = (flash.0 - time.delta_secs() * 1.2).max(0.0);
    // Santé basse : voile rouge permanent, de plus en plus marqué.
    let low = ((0.35 - player.fraction()) / 0.35).clamp(0.0, 1.0) * 0.3;
    overlay.0 = Color::srgba(0.7, 0.0, 0.0, (flash.0 * 0.5 + low).clamp(0.0, 0.7));
}

fn spawn_death_ui(mut commands: Commands, run: Res<Run>) {
    commands
        .spawn((
            DeathUi,
            Node {
                position_type: PositionType::Absolute,
                width: Val::Percent(100.0),
                height: Val::Percent(100.0),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(Color::srgba(0.05, 0.0, 0.0, 0.85)),
        ))
        .with_children(|root| {
            root.spawn((
                Text::new(format!(
                    "TU ES MORT\n\nNiveau atteint : {}\nLa sauvegarde est effacée.\n\n[R] Recommencer",
                    run.level
                )),
                font(34.0),
                TextColor(Color::srgb(0.9, 0.3, 0.3)),
            ));
        });
}

fn despawn_death_ui(mut commands: Commands, ui: Query<Entity, With<DeathUi>>) {
    for e in &ui {
        commands.entity(e).despawn();
    }
}

//! Types partagés : messages (dégâts, bruit, sons...), santé, marqueurs.

use bevy::prelude::*;

/// Tout ce qui appartient au niveau courant (supprimé à chaque changement de niveau).
#[derive(Component)]
pub struct LevelEntity;

#[derive(Component, Clone, Copy)]
pub struct Health {
    pub current: f32,
    pub max: f32,
}

impl Health {
    pub fn new(max: f32) -> Self {
        Self { current: max, max }
    }
    pub fn fraction(&self) -> f32 {
        (self.current / self.max).clamp(0.0, 1.0)
    }
}

/// Dégâts infligés à une entité qui a de la `Health`.
#[derive(Message)]
pub struct Damage {
    pub target: Entity,
    pub amount: f32,
}

/// Bruit émis : les monstres l'entendent dans le rayon donné (comme dans le vrai jeu).
#[derive(Message)]
pub struct Noise {
    pub pos: Vec3,
    pub radius: f32,
}

/// Choc détecté sur un objet physique (`strength` = variation de vitesse en m/s).
#[derive(Message)]
pub struct Impact {
    pub entity: Entity,
    pub pos: Vec3,
    pub strength: f32,
}

/// Petit message affiché à l'écran.
#[derive(Message)]
pub struct Toast(pub String);

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Sfx {
    Step1,
    Step2,
    Jump,
    Land,
    ImpactSoft,
    ImpactHard,
    Glass,
    Grab,
    Release,
    Throw,
    Flashlight,
    Error,
    Ding,
    Buy,
    Heal,
    Beep,
    Hurt,
    Death,
    Heartbeat,
    EnemyAlert,
    EnemyAttack,
    EnemyDie,
}

impl Sfx {
    pub const ALL: [Sfx; 22] = [
        Sfx::Step1,
        Sfx::Step2,
        Sfx::Jump,
        Sfx::Land,
        Sfx::ImpactSoft,
        Sfx::ImpactHard,
        Sfx::Glass,
        Sfx::Grab,
        Sfx::Release,
        Sfx::Throw,
        Sfx::Flashlight,
        Sfx::Error,
        Sfx::Ding,
        Sfx::Buy,
        Sfx::Heal,
        Sfx::Beep,
        Sfx::Hurt,
        Sfx::Death,
        Sfx::Heartbeat,
        Sfx::EnemyAlert,
        Sfx::EnemyAttack,
        Sfx::EnemyDie,
    ];

    pub fn file(self) -> &'static str {
        match self {
            Sfx::Step1 => "step1",
            Sfx::Step2 => "step2",
            Sfx::Jump => "jump",
            Sfx::Land => "land",
            Sfx::ImpactSoft => "impact_soft",
            Sfx::ImpactHard => "impact_hard",
            Sfx::Glass => "glass",
            Sfx::Grab => "grab",
            Sfx::Release => "release",
            Sfx::Throw => "throw",
            Sfx::Flashlight => "flashlight",
            Sfx::Error => "error",
            Sfx::Ding => "ding",
            Sfx::Buy => "buy",
            Sfx::Heal => "heal",
            Sfx::Beep => "beep",
            Sfx::Hurt => "hurt",
            Sfx::Death => "death",
            Sfx::Heartbeat => "heartbeat",
            Sfx::EnemyAlert => "enemy_alert",
            Sfx::EnemyAttack => "enemy_attack",
            Sfx::EnemyDie => "enemy_die",
        }
    }
}

/// Demande de lecture d'un son. `pos = Some(..)` : son spatialisé (3D) ; sinon son « dans la tête ».
#[derive(Message)]
pub struct PlaySfx {
    pub sfx: Sfx,
    pub pos: Option<Vec3>,
    pub volume: f32,
}

impl PlaySfx {
    pub fn flat(sfx: Sfx, volume: f32) -> Self {
        Self { sfx, pos: None, volume }
    }
    pub fn at(sfx: Sfx, pos: Vec3, volume: f32) -> Self {
        Self { sfx, pos: Some(pos), volume }
    }
}

pub struct CommonPlugin;

impl Plugin for CommonPlugin {
    fn build(&self, app: &mut App) {
        app.add_message::<Damage>()
            .add_message::<Noise>()
            .add_message::<Impact>()
            .add_message::<Toast>()
            .add_message::<PlaySfx>();
    }
}

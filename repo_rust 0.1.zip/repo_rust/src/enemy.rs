//! Monstres : patrouille, écoute les bruits, repère le joueur, poursuit et attaque.
//!
//! Comme dans le vrai jeu, ils réagissent surtout au bruit (pas, chocs, extraction),
//! et ils sont soumis à la physique : un objet lancé leur fait mal.

use avian3d::prelude::*;
use bevy::prelude::*;

use crate::common::*;
use crate::game::GameState;
use crate::grab::Grabbable;
use crate::nav::NavGrid;
use crate::player::Player;
use crate::rng::Rng;
use crate::textures::{Gfx, Tex};
use crate::valuables::{ValuableSpec, spawn_valuable};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum EnemyKind {
    /// Petit et rapide, peu résistant : danger de niveau 1.
    Gnome,
    /// Lent à repérer mais costaud et dévastateur : danger de niveau 2.
    Brute,
}

struct Stats {
    name: &'static str,
    hp: f32,
    patrol_speed: f32,
    chase_speed: f32,
    damage: f32,
    attack_range: f32,
    attack_cooldown: f32,
    sight: f32,
    /// Multiplicateur du rayon d'écoute.
    hearing: f32,
    drop_value: f32,
    radius: f32,
    length: f32,
    mass: f32,
    color: Color,
}

impl EnemyKind {
    fn stats(self) -> Stats {
        match self {
            EnemyKind::Gnome => Stats {
                name: "Gnome",
                hp: 30.0,
                patrol_speed: 1.8,
                chase_speed: 4.2,
                damage: 8.0,
                attack_range: 1.3,
                attack_cooldown: 1.0,
                sight: 12.0,
                hearing: 1.0,
                drop_value: 1800.0,
                radius: 0.25,
                length: 0.5,
                mass: 25.0,
                color: Color::srgb(0.2, 0.5, 0.25),
            },
            EnemyKind::Brute => Stats {
                name: "Brute",
                hp: 120.0,
                patrol_speed: 2.0,
                chase_speed: 5.2,
                damage: 30.0,
                attack_range: 1.8,
                attack_cooldown: 1.4,
                sight: 16.0,
                hearing: 1.3,
                drop_value: 5000.0,
                radius: 0.45,
                length: 1.0,
                mass: 120.0,
                color: Color::srgb(0.35, 0.08, 0.1),
            },
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Ai {
    /// Attend avant de repartir.
    Idle(f32),
    Wander,
    /// Va voir d'où venait un bruit.
    Investigate(Vec3),
    Chase,
}

#[derive(Component)]
pub struct Enemy {
    kind: EnemyKind,
    ai: Ai,
    path: Vec<Vec3>,
    path_i: usize,
    repath: f32,
    attack_cd: f32,
    hit_cd: f32,
    since_seen: f32,
    last_known: Vec3,
    voice_cd: f32,
}

pub struct EnemyPlugin;

impl Plugin for EnemyPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(
            FixedUpdate,
            (enemy_ai, enemy_hits).run_if(in_state(GameState::Playing)),
        )
        .add_systems(Update, enemy_death.run_if(in_state(GameState::Playing)));
    }
}

pub fn spawn_enemy(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    materials: &mut Assets<StandardMaterial>,
    kind: EnemyKind,
    pos: Vec3,
    voice_cd: f32,
) {
    let st = kind.stats();
    let half = st.length / 2.0 + st.radius;
    let body = materials.add(StandardMaterial {
        base_color: st.color,
        perceptual_roughness: 0.8,
        ..default()
    });
    let eye_material = materials.add(StandardMaterial {
        base_color: Color::BLACK,
        emissive: LinearRgba::new(5.0, 0.3, 0.1, 1.0),
        ..default()
    });
    let eye_mesh = meshes.add(Sphere::new(0.06));
    commands
        .spawn((
            LevelEntity,
            Name::new(st.name),
            Enemy {
                kind,
                ai: Ai::Idle(1.0),
                path: Vec::new(),
                path_i: 0,
                repath: 0.0,
                attack_cd: 0.0,
                hit_cd: 0.0,
                since_seen: 0.0,
                last_known: pos,
                voice_cd,
            },
            Health::new(st.hp),
            Mesh3d(meshes.add(Capsule3d::new(st.radius, st.length))),
            MeshMaterial3d(body),
            Transform::from_translation(pos + Vec3::Y * half),
            RigidBody::Dynamic,
            Collider::capsule(st.radius, st.length),
            LockedAxes::ROTATION_LOCKED,
            SleepingDisabled,
            Friction::ZERO.with_combine_rule(CoefficientCombine::Min),
            Mass(st.mass),
            CollidingEntities::default(),
        ))
        .with_children(|parent| {
            // Deux yeux brillants, à l'avant (-Z) : on voit où il regarde.
            for side in [-1.0, 1.0] {
                parent.spawn((
                    Mesh3d(eye_mesh.clone()),
                    MeshMaterial3d(eye_material.clone()),
                    Transform::from_xyz(side * st.radius * 0.45, half * 0.55, -st.radius * 0.85),
                ));
            }
        });
}

/// Prochaine direction à suivre le long du chemin, ou `None` si on est arrivé.
fn follow(path: &[Vec3], index: &mut usize, pos: Vec3) -> Option<Vec3> {
    while *index < path.len() && Vec2::new(path[*index].x - pos.x, path[*index].z - pos.z).length() < 0.45 {
        *index += 1;
    }
    path.get(*index)
        .map(|p| Vec3::new(p.x - pos.x, 0.0, p.z - pos.z).normalize_or_zero())
}

#[allow(clippy::too_many_arguments)]
fn enemy_ai(
    time: Res<Time>,
    nav: Res<NavGrid>,
    spatial: SpatialQuery,
    player: Single<(Entity, &Transform), (With<Player>, Without<Enemy>)>,
    mut enemies: Query<(Entity, &mut Transform, &mut LinearVelocity, &mut Enemy)>,
    mut noises: MessageReader<Noise>,
    mut rng: ResMut<Rng>,
    mut sfx: MessageWriter<PlaySfx>,
    mut damage: MessageWriter<Damage>,
) {
    let (player_entity, player_tf) = *player;
    let ppos = player_tf.translation;
    let dt = time.delta_secs();
    let heard: Vec<(Vec3, f32)> = noises.read().map(|n| (n.pos, n.radius)).collect();

    for (entity, mut tf, mut velocity, mut enemy) in &mut enemies {
        let st = enemy.kind.stats();
        let pos = tf.translation;
        enemy.attack_cd -= dt;
        enemy.repath -= dt;
        enemy.voice_cd -= dt;

        // --- Vue : à portée, devant lui (ou tout près), et sans mur entre nous.
        let eye = pos + Vec3::Y * 0.4;
        let to = (ppos + Vec3::Y * 0.4) - eye;
        let dist = to.length();
        let facing = tf.rotation * Vec3::NEG_Z;
        let flat_to = Vec3::new(to.x, 0.0, to.z).normalize_or_zero();
        let in_view = dist < 2.5 || flat_to.dot(facing) > 0.2;
        let mut sees = false;
        if dist < st.sight && in_view {
            if let Ok(dir) = Dir3::new(to) {
                let filter = SpatialQueryFilter::from_excluded_entities([entity]);
                sees = spatial
                    .cast_ray(eye, dir, dist, true, &filter)
                    .is_some_and(|hit| hit.entity == player_entity);
            }
        }

        // --- Changements d'état.
        if sees {
            if enemy.ai != Ai::Chase {
                sfx.write(PlaySfx::at(Sfx::EnemyAlert, pos, 1.0));
                enemy.ai = Ai::Chase;
                enemy.repath = 0.0;
            }
            enemy.since_seen = 0.0;
            enemy.last_known = ppos;
        } else if enemy.ai == Ai::Chase {
            enemy.since_seen += dt;
            if enemy.since_seen > 5.0 {
                enemy.ai = Ai::Investigate(enemy.last_known);
                enemy.repath = 0.0;
            }
        } else if let Some((noise_pos, _)) = heard
            .iter()
            .find(|(p, r)| pos.distance(*p) < r * st.hearing)
        {
            enemy.ai = Ai::Investigate(*noise_pos);
            enemy.repath = 0.0;
        }

        // Grognement d'ambiance : on entend les monstres avant de les voir.
        if enemy.voice_cd <= 0.0 && enemy.ai != Ai::Chase {
            sfx.write(PlaySfx::at(Sfx::EnemyAlert, pos, 0.45));
            enemy.voice_cd = rng.range(9.0, 18.0);
        }

        // --- Comportement.
        let mut desired = Vec3::ZERO;
        let mut speed = st.patrol_speed;
        let mut face_player = false;

        match enemy.ai {
            Ai::Idle(wait) => {
                let wait = wait - dt;
                if wait > 0.0 {
                    enemy.ai = Ai::Idle(wait);
                } else if nav.room_centers.is_empty() {
                    enemy.ai = Ai::Idle(2.0);
                } else {
                    let target = nav.room_centers[rng.index(nav.room_centers.len())];
                    match nav.path(pos, target) {
                        Some(path) => {
                            enemy.path = path;
                            enemy.path_i = 0;
                            enemy.ai = Ai::Wander;
                        }
                        None => enemy.ai = Ai::Idle(1.0),
                    }
                }
            }
            Ai::Wander | Ai::Investigate(_) => {
                if let Ai::Investigate(target) = enemy.ai {
                    if enemy.repath <= 0.0 {
                        enemy.repath = 99.0;
                        enemy.path = nav.path(pos, target).unwrap_or_default();
                        enemy.path_i = 0;
                    }
                    speed = st.patrol_speed * 1.6;
                }
                let mut index = enemy.path_i;
                match follow(&enemy.path, &mut index, pos) {
                    Some(dir) => desired = dir,
                    None => {
                        enemy.ai = Ai::Idle(if matches!(enemy.ai, Ai::Wander) {
                            rng.range(1.5, 4.0)
                        } else {
                            2.5
                        });
                    }
                }
                enemy.path_i = index;
            }
            Ai::Chase => {
                speed = st.chase_speed;
                if dist < st.attack_range + 0.4 && sees {
                    // À portée : on s'arrête et on frappe.
                    face_player = true;
                    if enemy.attack_cd <= 0.0 {
                        enemy.attack_cd = st.attack_cooldown;
                        damage.write(Damage { target: player_entity, amount: st.damage });
                        sfx.write(PlaySfx::at(Sfx::EnemyAttack, pos, 1.0));
                    }
                } else {
                    if enemy.repath <= 0.0 {
                        enemy.repath = 0.4;
                        enemy.path = nav.path(pos, ppos).unwrap_or_default();
                        enemy.path_i = 0;
                    }
                    let mut index = enemy.path_i;
                    if let Some(dir) = follow(&enemy.path, &mut index, pos) {
                        desired = dir;
                    }
                    enemy.path_i = index;
                }
            }
        }

        // --- Mouvement et orientation.
        let target_v = desired * speed;
        let t = (10.0 * dt).min(1.0);
        velocity.x += (target_v.x - velocity.x) * t;
        velocity.z += (target_v.z - velocity.z) * t;

        let look = if face_player { flat_to } else { desired };
        if look != Vec3::ZERO {
            let yaw = f32::atan2(-look.x, -look.z);
            tf.rotation = tf.rotation.slerp(Quat::from_rotation_y(yaw), (8.0 * dt).min(1.0));
        }
    }
}

/// Un objet lourd lancé (ou traîné vite) contre un monstre lui fait mal.
fn enemy_hits(
    time: Res<Time>,
    mut enemies: Query<(Entity, &Transform, &CollidingEntities, &mut Enemy)>,
    objects: Query<(&LinearVelocity, &Mass), With<Grabbable>>,
    mut damage: MessageWriter<Damage>,
    mut sfx: MessageWriter<PlaySfx>,
) {
    let dt = time.delta_secs();
    for (entity, transform, colliding, mut enemy) in &mut enemies {
        enemy.hit_cd -= dt;
        if enemy.hit_cd > 0.0 {
            continue;
        }
        for other in colliding.iter() {
            let Ok((velocity, mass)) = objects.get(*other) else { continue };
            let speed = velocity.length();
            if speed > 3.5 && mass.0 > 1.5 {
                enemy.hit_cd = 0.4;
                damage.write(Damage { target: entity, amount: speed * mass.0 * 0.4 });
                sfx.write(PlaySfx::at(Sfx::ImpactHard, transform.translation, 0.9));
                break;
            }
        }
    }
}

fn enemy_death(
    mut commands: Commands,
    enemies: Query<(Entity, &Health, &Enemy, &Transform)>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut gfx: ResMut<Gfx>,
    mut sfx: MessageWriter<PlaySfx>,
    mut toasts: MessageWriter<Toast>,
) {
    for (entity, health, enemy, transform) in &enemies {
        if health.current > 0.0 {
            continue;
        }
        let st = enemy.kind.stats();
        commands.entity(entity).despawn();
        sfx.write(PlaySfx::at(Sfx::EnemyDie, transform.translation, 1.0));
        toasts.write(Toast(format!("{} éliminé : il laisse un orbe de valeur.", st.name)));
        // Comme dans le vrai jeu, le monstre abattu laisse un objet de valeur.
        spawn_valuable(
            &mut commands,
            &mut meshes,
            &mut materials,
            &mut gfx,
            ValuableSpec {
                name: "Orbe de monstre",
                size: Vec3::splat(0.3),
                mass: 2.0,
                value: st.drop_value,
                fragility: 0.3,
                color: Color::srgb(0.6, 0.25, 0.85),
                tex: Tex::Metal,
            },
            transform.translation + Vec3::Y * 0.4,
        );
    }
}

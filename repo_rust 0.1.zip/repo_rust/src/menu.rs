//! Menu d'accueil, menu pause, et gestion de la souris selon l'état du jeu.
//!
//! Les boutons utilisent `Interaction` : déprécié dans Bevy 0.20 mais toujours fonctionnel
//! (le remplaçant dépend du module de « picking », que ce jeu n'embarque pas).
#![allow(deprecated)]

use avian3d::prelude::*;
use bevy::prelude::*;
use bevy::text::FontSize;
use bevy::ui::GlobalZIndex;
use bevy::window::{CursorGrabMode, CursorOptions, PrimaryWindow};

use crate::game::{GameState, Run};

#[derive(Component)]
struct MenuUi;

#[derive(Component)]
struct PauseUi;

#[derive(Component, Clone, Copy)]
enum MenuButton {
    Play,
    Resume,
    MainMenu,
    Quit,
}

const NORMAL: Color = Color::srgb(0.14, 0.14, 0.17);
const HOVERED: Color = Color::srgb(0.28, 0.28, 0.34);
const PRESSED: Color = Color::srgb(0.55, 0.2, 0.2);

pub struct MenuPlugin;

impl Plugin for MenuPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(GameState::Menu), spawn_main_menu)
            .add_systems(OnExit(GameState::Menu), despawn_all::<MenuUi>)
            .add_systems(OnEnter(GameState::Paused), (spawn_pause_menu, pause_physics))
            .add_systems(OnExit(GameState::Paused), (despawn_all::<PauseUi>, resume_physics))
            // Souris capturée en jeu, libre partout ailleurs.
            .add_systems(OnEnter(GameState::Playing), capture_cursor)
            .add_systems(
                OnEnter(GameState::Menu),
                release_cursor,
            )
            .add_systems(OnEnter(GameState::Paused), release_cursor)
            .add_systems(OnEnter(GameState::Shop), release_cursor)
            .add_systems(OnEnter(GameState::Dead), release_cursor)
            .add_systems(Update, (button_colors, button_actions, shortcuts));
    }
}

fn despawn_all<C: Component>(mut commands: Commands, q: Query<Entity, With<C>>) {
    for e in &q {
        commands.entity(e).despawn();
    }
}

fn pause_physics(mut time: ResMut<Time<Physics>>) {
    time.pause();
}

fn resume_physics(mut time: ResMut<Time<Physics>>) {
    time.unpause();
}

fn capture_cursor(mut cursor: Single<&mut CursorOptions, With<PrimaryWindow>>) {
    cursor.grab_mode = CursorGrabMode::Locked;
    cursor.visible = false;
}

fn release_cursor(mut cursor: Single<&mut CursorOptions, With<PrimaryWindow>>) {
    cursor.grab_mode = CursorGrabMode::None;
    cursor.visible = true;
}

fn font(size: f32) -> TextFont {
    TextFont { font_size: FontSize::Px(size), ..default() }
}

fn button(parent: &mut ChildSpawnerCommands, label: &str, action: MenuButton) {
    parent
        .spawn((
            Interaction::None,
            action,
            Node {
                width: Val::Px(300.0),
                height: Val::Px(54.0),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(NORMAL),
        ))
        .with_children(|b| {
            b.spawn((Text::new(label), font(26.0), TextColor(Color::WHITE)));
        });
}

fn overlay(alpha: f32) -> impl Bundle {
    (
        Node {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            flex_direction: FlexDirection::Column,
            justify_content: JustifyContent::Center,
            align_items: AlignItems::Center,
            row_gap: Val::Px(14.0),
            ..default()
        },
        BackgroundColor(Color::srgba(0.03, 0.03, 0.05, alpha)),
        GlobalZIndex(100),
    )
}

fn spawn_main_menu(mut commands: Commands) {
    commands.spawn((MenuUi, overlay(1.0))).with_children(|root| {
        root.spawn((Text::new("R.E.P.O."), font(84.0), TextColor(Color::srgb(0.9, 0.35, 0.2))));
        root.spawn((
            Text::new("version Rust - prototype"),
            font(20.0),
            TextColor(Color::srgb(0.6, 0.6, 0.65)),
            Node { margin: UiRect::bottom(Val::Px(28.0)), ..default() },
        ));
        button(root, "Jouer", MenuButton::Play);
        button(root, "Quitter", MenuButton::Quit);
        root.spawn((
            Text::new(
                "WASD / ZQSD : bouger   Maj : courir   Ctrl : s'accroupir   Espace : sauter   F : lampe\n\
                 Clic droit : attraper   Clic gauche : lancer   E : utiliser   H : soin   Echap : pause",
            ),
            font(16.0),
            TextColor(Color::srgba(1.0, 1.0, 1.0, 0.45)),
            Node { margin: UiRect::top(Val::Px(36.0)), ..default() },
        ));
    });
}

fn spawn_pause_menu(mut commands: Commands) {
    commands.spawn((PauseUi, overlay(0.8))).with_children(|root| {
        root.spawn((
            Text::new("PAUSE"),
            font(56.0),
            TextColor(Color::WHITE),
            Node { margin: UiRect::bottom(Val::Px(20.0)), ..default() },
        ));
        button(root, "Reprendre", MenuButton::Resume);
        button(root, "Menu principal", MenuButton::MainMenu);
        button(root, "Quitter", MenuButton::Quit);
    });
}

fn button_colors(
    mut buttons: Query<(&Interaction, &mut BackgroundColor), (Changed<Interaction>, With<MenuButton>)>,
) {
    for (interaction, mut color) in &mut buttons {
        color.0 = match interaction {
            Interaction::Pressed => PRESSED,
            Interaction::Hovered => HOVERED,
            Interaction::None => NORMAL,
        };
    }
}

fn button_actions(
    buttons: Query<(&Interaction, &MenuButton), Changed<Interaction>>,
    mut run: ResMut<Run>,
    mut next: ResMut<NextState<GameState>>,
    mut exit: MessageWriter<AppExit>,
) {
    for (interaction, action) in &buttons {
        if *interaction != Interaction::Pressed {
            continue;
        }
        match action {
            MenuButton::Play => {
                *run = Run::default();
                next.set(GameState::Playing);
            }
            MenuButton::Resume => next.set(GameState::Playing),
            MenuButton::MainMenu => next.set(GameState::Menu),
            MenuButton::Quit => {
                exit.write(AppExit::Success);
            }
        }
    }
}

/// Entrée : jouer depuis le menu. Échap : pause / reprise.
fn shortcuts(
    keys: Res<ButtonInput<KeyCode>>,
    state: Res<State<GameState>>,
    mut run: ResMut<Run>,
    mut next: ResMut<NextState<GameState>>,
) {
    match state.get() {
        GameState::Menu if keys.just_pressed(KeyCode::Enter) => {
            *run = Run::default();
            next.set(GameState::Playing);
        }
        GameState::Playing if keys.just_pressed(KeyCode::Escape) => next.set(GameState::Paused),
        GameState::Paused if keys.just_pressed(KeyCode::Escape) => next.set(GameState::Playing),
        _ => {}
    }
}

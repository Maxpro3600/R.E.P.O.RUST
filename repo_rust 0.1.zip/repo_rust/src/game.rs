//! États de la partie (menu, jeu, pause, boutique, mort) et progression (« run »).

use bevy::prelude::*;

#[derive(States, Default, Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum GameState {
    /// État initial : le temps que le joueur et l'interface soient créés (Startup).
    #[default]
    Loading,
    Menu,
    Playing,
    Paused,
    Shop,
    Dead,
}

/// Progression de la partie en cours (perdue à la mort, comme la sauvegarde dans le vrai jeu).
#[derive(Resource)]
pub struct Run {
    pub level: u32,
    /// Surplus : l'argent à dépenser à la boutique.
    pub money: f32,
    /// Valeur déjà extraite pendant ce niveau.
    pub banked: f32,
    /// Quota total du niveau (somme des quotas des plateformes).
    pub goal: f32,
    pub extractions_total: u32,
    pub extractions_done: u32,
    pub packs: u32,
    pub health_lvl: u32,
    pub stamina_lvl: u32,
    pub strength_lvl: u32,
    pub speed_lvl: u32,
    /// Vrai au tout début d'une partie : le joueur reçoit sa santé complète.
    pub fresh: bool,
    /// Vrai quand il faut générer un nouveau niveau en entrant dans `Playing`
    /// (et pas quand on reprend après une pause).
    pub needs_level: bool,
}

impl Default for Run {
    fn default() -> Self {
        Self {
            level: 1,
            money: 0.0,
            banked: 0.0,
            goal: Run::goal_for(1),
            extractions_total: 1,
            extractions_done: 0,
            packs: 0,
            health_lvl: 0,
            stamina_lvl: 0,
            strength_lvl: 0,
            speed_lvl: 0,
            fresh: true,
            needs_level: true,
        }
    }
}

impl Run {
    pub fn goal_for(level: u32) -> f32 {
        2500.0 + 1000.0 * level as f32
    }
    pub fn max_health(&self) -> f32 {
        100.0 + 20.0 * self.health_lvl as f32
    }
    pub fn max_stamina(&self) -> f32 {
        100.0 + 20.0 * self.stamina_lvl as f32
    }
    pub fn strength_mult(&self) -> f32 {
        1.0 + 0.25 * self.strength_lvl as f32
    }
    pub fn speed_mult(&self) -> f32 {
        1.0 + 0.07 * self.speed_lvl as f32
    }
    /// Toutes les extractions sont faites : on peut repartir avec le camion.
    pub fn all_extracted(&self) -> bool {
        self.extractions_done >= self.extractions_total
    }
}

pub struct GamePlugin;

impl Plugin for GamePlugin {
    fn build(&self, app: &mut App) {
        app.init_state::<GameState>()
            .init_resource::<Run>()
            // L'état initial est activé AVANT Startup : on attend donc que le joueur et
            // l'interface existent avant d'afficher le menu. Aucun niveau n'est généré
            // tant qu'on n'a pas cliqué sur « Jouer » : le démarrage est quasi instantané.
            .add_systems(Startup, |mut next: ResMut<NextState<GameState>>| next.set(GameState::Menu))
            .add_systems(Update, restart_after_death.run_if(in_state(GameState::Dead)));
    }
}

fn restart_after_death(
    keys: Res<ButtonInput<KeyCode>>,
    mut run: ResMut<Run>,
    mut next: ResMut<NextState<GameState>>,
) {
    if keys.just_pressed(KeyCode::KeyR) {
        *run = Run::default();
        next.set(GameState::Playing);
    }
}

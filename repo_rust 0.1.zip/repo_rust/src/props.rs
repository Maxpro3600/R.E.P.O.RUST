//! Décor : étagères, bureaux, casiers, tonneaux, canapés, tuyaux... et leur placement dans les pièces.

use std::f32::consts::{FRAC_PI_2, PI};

use avian3d::prelude::*;
use bevy::color::Mix;
use bevy::prelude::*;

use crate::common::LevelEntity;
use crate::grab::Grabbable;
use crate::impact::Impactor;
use crate::nav::NavGrid;
use crate::rng::Rng;
use crate::textures::{Gfx, Tex};

pub const ROOM: f32 = 12.0;
pub const WALL_T: f32 = 0.4;
/// Rayon d'un monstre : les obstacles sont « gonflés » d'autant pour la navigation.
pub const AGENT_R: f32 = 0.45;
/// Face intérieure des murs, depuis le centre d'une pièce.
const INNER: f32 = ROOM / 2.0 - WALL_T / 2.0;
/// Demi-largeur de passage laissée libre devant chaque porte.
const DOOR_CLEAR: f32 = 2.2;

/// Tout ce qu'il faut pour fabriquer des objets du niveau.
pub struct Ctx<'a, 'w, 's> {
    pub commands: &'a mut Commands<'w, 's>,
    pub meshes: &'a mut Assets<Mesh>,
    pub materials: &'a mut Assets<StandardMaterial>,
    pub gfx: &'a mut Gfx,
    pub nav: &'a mut NavGrid,
}

/// Les dimensions (x, z) d'un objet de largeur `w` et profondeur `d` tourné de `yaw` (multiple de 90°).
fn footprint(w: f32, d: f32, yaw: f32) -> Vec2 {
    if ((yaw / FRAC_PI_2).round() as i32).rem_euclid(2) == 1 {
        Vec2::new(d / 2.0, w / 2.0)
    } else {
        Vec2::new(w / 2.0, d / 2.0)
    }
}

impl Ctx<'_, '_, '_> {
    fn block(&mut self, center: Vec3, half_xz: Vec2) {
        self.nav
            .block_aabb(Vec2::new(center.x, center.z), half_xz + Vec2::splat(AGENT_R));
    }

    /// Bloc statique texturé, sans rotation (murs, sols...).
    pub fn solid(&mut self, tex: Tex, tint: Color, center: Vec3, size: Vec3, block_nav: bool) -> Entity {
        if block_nav {
            self.block(center, Vec2::new(size.x, size.z) / 2.0);
        }
        let mesh = self.gfx.box_mesh(self.meshes, size, tex.tile_meters());
        let material = self.gfx.material(self.materials, tex, tint);
        self.commands
            .spawn((
                LevelEntity,
                Mesh3d(mesh),
                MeshMaterial3d(material),
                Transform::from_translation(center),
                RigidBody::Static,
                Collider::cuboid(size.x, size.y, size.z),
            ))
            .id()
    }

    /// Élément purement visuel (sans collision).
    pub fn decor(&mut self, tex: Tex, tint: Color, center: Vec3, size: Vec3, yaw: f32) {
        let mesh = self.gfx.box_mesh(self.meshes, size, tex.tile_meters());
        let material = self.gfx.material(self.materials, tex, tint);
        self.commands.spawn((
            LevelEntity,
            Mesh3d(mesh),
            MeshMaterial3d(material),
            Transform::from_translation(center).with_rotation(Quat::from_rotation_y(yaw)),
        ));
    }

    /// Objet composé statique : le parent porte le corps rigide, les pièces ses collisions.
    fn compound(&mut self, name: &str, pos: Vec3, yaw: f32) -> Entity {
        self.commands
            .spawn((
                LevelEntity,
                Name::new(name.to_string()),
                Transform::from_translation(pos).with_rotation(Quat::from_rotation_y(yaw)),
                Visibility::default(),
                RigidBody::Static,
            ))
            .id()
    }

    fn part(&mut self, parent: Entity, tex: Tex, tint: Color, local: Vec3, size: Vec3, collide: bool) {
        let material = self.gfx.material(self.materials, tex, tint);
        self.part_with(parent, material, tex.tile_meters(), local, size, collide);
    }

    fn part_with(
        &mut self,
        parent: Entity,
        material: Handle<StandardMaterial>,
        tile: f32,
        local: Vec3,
        size: Vec3,
        collide: bool,
    ) {
        let mesh = self.gfx.box_mesh(self.meshes, size, tile);
        let child = self
            .commands
            .spawn((Mesh3d(mesh), MeshMaterial3d(material), Transform::from_translation(local)))
            .id();
        if collide {
            self.commands.entity(child).insert(Collider::cuboid(size.x, size.y, size.z));
        }
        self.commands.entity(parent).add_child(child);
    }

    /// Boîte statique orientée (casier, pilier...). `pos` est au sol.
    pub fn boxed(&mut self, name: &str, tex: Tex, tint: Color, pos: Vec3, size: Vec3, yaw: f32) {
        self.block(pos, footprint(size.x, size.z, yaw));
        let parent = self.compound(name, pos, yaw);
        self.part(parent, tex, tint, Vec3::new(0.0, size.y / 2.0, 0.0), size, true);
    }

    /// Étagère à 4 niveaux. Renvoie les emplacements (monde) où poser des objets.
    pub fn shelf(&mut self, pos: Vec3, yaw: f32, tint: Color) -> Vec<Vec3> {
        const W: f32 = 2.0;
        const D: f32 = 0.5;
        const H: f32 = 2.1;
        self.block(pos, footprint(W, D, yaw));
        let parent = self.compound("Étagère", pos, yaw);
        for side in [-1.0, 1.0] {
            self.part(parent, Tex::Wood, tint, Vec3::new(side * (W / 2.0 - 0.03), H / 2.0, 0.0), Vec3::new(0.06, H, D), true);
        }
        let back = tint.mix(&Color::BLACK, 0.25);
        self.part(parent, Tex::Wood, back, Vec3::new(0.0, H / 2.0, -D / 2.0 + 0.015), Vec3::new(W - 0.12, H, 0.03), true);
        let levels = [0.1, 0.68, 1.26, 1.84, 2.1];
        for y in levels {
            self.part(parent, Tex::Wood, tint, Vec3::new(0.0, y, 0.015), Vec3::new(W - 0.12, 0.05, D - 0.03), true);
        }
        let rot = Quat::from_rotation_y(yaw);
        let mut slots = Vec::new();
        for y in &levels[..4] {
            for x in [-0.6, 0.0, 0.6] {
                slots.push(pos + rot * Vec3::new(x, y + 0.03, 0.03));
            }
        }
        slots
    }

    /// Table (plateau + 4 pieds). Renvoie le parent et le point central du plateau.
    fn table(&mut self, pos: Vec3, yaw: f32, size: Vec3, tint: Color) -> (Entity, Vec3) {
        let (w, h, d) = (size.x, size.y, size.z);
        self.block(pos, footprint(w, d, yaw));
        let parent = self.compound("Table", pos, yaw);
        self.part(parent, Tex::Wood, tint, Vec3::new(0.0, h - 0.03, 0.0), Vec3::new(w, 0.06, d), true);
        for sx in [-1.0, 1.0] {
            for sz in [-1.0, 1.0] {
                let leg = Vec3::new(sx * (w / 2.0 - 0.07), (h - 0.06) / 2.0, sz * (d / 2.0 - 0.07));
                self.part(parent, Tex::Wood, tint, leg, Vec3::new(0.08, h - 0.06, 0.08), true);
            }
        }
        (parent, pos + Vec3::Y * h)
    }

    /// Bureau avec écran allumé et clavier.
    pub fn desk(&mut self, pos: Vec3, yaw: f32, tint: Color) {
        let h = 0.75;
        let (parent, _) = self.table(pos, yaw, Vec3::new(1.6, h, 0.8), tint);
        let dark = Color::srgb(0.08, 0.08, 0.09);
        self.part(parent, Tex::Metal, dark, Vec3::new(0.0, h + 0.05, -0.2), Vec3::new(0.06, 0.1, 0.06), false);
        let screen = self.materials.add(StandardMaterial {
            base_color: Color::BLACK,
            emissive: LinearRgba::new(0.08, 0.3, 0.55, 1.0),
            ..default()
        });
        self.part_with(parent, screen, 1.0, Vec3::new(0.0, h + 0.3, -0.22), Vec3::new(0.55, 0.34, 0.04), false);
        self.part(parent, Tex::Metal, dark, Vec3::new(0.0, h + 0.015, 0.12), Vec3::new(0.42, 0.03, 0.14), false);
    }

    pub fn locker(&mut self, pos: Vec3, yaw: f32, tint: Color) {
        self.boxed("Casier", Tex::Metal, tint, pos, Vec3::new(0.5, 1.9, 0.5), yaw);
    }

    pub fn pillar(&mut self, pos: Vec3) {
        self.boxed("Pilier", Tex::Concrete, Color::srgb(0.85, 0.85, 0.85), pos, Vec3::new(0.6, 4.0, 0.6), 0.0);
    }

    pub fn sofa(&mut self, pos: Vec3, yaw: f32, tint: Color) {
        self.block(pos, footprint(1.8, 0.8, yaw));
        let parent = self.compound("Canapé", pos, yaw);
        self.part(parent, Tex::Carpet, tint, Vec3::new(0.0, 0.21, 0.0), Vec3::new(1.8, 0.42, 0.8), true);
        self.part(parent, Tex::Carpet, tint, Vec3::new(0.0, 0.67, -0.3), Vec3::new(1.8, 0.5, 0.2), true);
        for side in [-1.0, 1.0] {
            self.part(parent, Tex::Carpet, tint, Vec3::new(side * 0.8, 0.55, 0.0), Vec3::new(0.2, 0.3, 0.8), true);
        }
    }

    pub fn rug(&mut self, center: Vec3, yaw: f32, tint: Color) {
        self.decor(Tex::Carpet, tint, center + Vec3::Y * 0.015, Vec3::new(3.4, 0.03, 2.4), yaw);
    }

    /// Réservoir cylindrique statique.
    pub fn tank(&mut self, pos: Vec3, tint: Color) {
        let (r, h) = (0.6, 2.2);
        self.block(pos, Vec2::splat(r));
        let mesh = self.gfx.shape(self.meshes, "tank", || Cylinder::new(0.6, 2.2).into());
        let material = self.gfx.material(self.materials, Tex::Metal, tint);
        self.commands.spawn((
            LevelEntity,
            Name::new("Réservoir"),
            Mesh3d(mesh),
            MeshMaterial3d(material),
            Transform::from_translation(pos + Vec3::Y * h / 2.0),
            RigidBody::Static,
            Collider::cylinder(r, h),
        ));
    }

    /// Tonneau : un vrai objet physique, qu'on peut traîner et lancer.
    pub fn barrel(&mut self, pos: Vec3, tint: Color) {
        let mesh = self.gfx.shape(self.meshes, "barrel", || Cylinder::new(0.3, 0.9).into());
        let material = self.gfx.material(self.materials, Tex::Metal, tint);
        self.commands.spawn((
            LevelEntity,
            Name::new("Tonneau"),
            Grabbable,
            Impactor::default(),
            Mesh3d(mesh),
            MeshMaterial3d(material),
            Transform::from_translation(pos + Vec3::Y * 0.45),
            RigidBody::Dynamic,
            Collider::cylinder(0.3, 0.9),
            Mass(25.0),
        ));
    }

    /// Caisse ou carton déplaçable.
    pub fn crate_box(&mut self, name: &str, pos: Vec3, size: f32, mass: f32, tint: Color) {
        let mesh = self.gfx.box_mesh(self.meshes, Vec3::splat(size), 1.0);
        let material = self.gfx.material(self.materials, Tex::Wood, tint);
        self.commands.spawn((
            LevelEntity,
            Name::new(name.to_string()),
            Grabbable,
            Impactor::default(),
            Mesh3d(mesh),
            MeshMaterial3d(material),
            Transform::from_translation(pos),
            RigidBody::Dynamic,
            Collider::cuboid(size, size, size),
            Mass(mass),
        ));
    }

    /// Tuyau au plafond, d'un mur à l'autre de la pièce (purement visuel).
    pub fn pipe(&mut self, center: Vec3, along_x: bool, tint: Color) {
        let mesh = self.gfx.shape(self.meshes, "pipe", || Cylinder::new(0.12, ROOM).into());
        let material = self.gfx.material(self.materials, Tex::Metal, tint);
        let rotation = if along_x {
            Quat::from_rotation_z(FRAC_PI_2)
        } else {
            Quat::from_rotation_x(FRAC_PI_2)
        };
        self.commands.spawn((
            LevelEntity,
            Mesh3d(mesh),
            MeshMaterial3d(material),
            Transform::from_translation(center).with_rotation(rotation),
        ));
    }
}

/// Réserve des emplacements dans une pièce pour que les objets ne se chevauchent pas.
#[derive(Default)]
pub struct Placer {
    occupied: Vec<(Vec2, Vec2)>,
}

impl Placer {
    pub fn reserve(&mut self, center: Vec2, half: Vec2) {
        self.occupied.push((center, half));
    }

    fn free(&self, center: Vec2, half: Vec2) -> bool {
        self.occupied.iter().all(|(c, h)| {
            (center.x - c.x).abs() > half.x + h.x + 0.3 || (center.y - c.y).abs() > half.y + h.y + 0.3
        })
    }

    /// Un emplacement adossé à un mur, hors des portes : position au sol et orientation (face vers la pièce).
    pub fn wall_spot(&mut self, rng: &mut Rng, room: Vec3, width: f32, depth: f32) -> Option<(Vec3, f32)> {
        let (lo, hi) = (DOOR_CLEAR + width / 2.0, INNER - 0.05 - width / 2.0);
        if hi < lo {
            return None;
        }
        for _ in 0..12 {
            let t = rng.range(lo, hi) * if rng.chance(0.5) { 1.0 } else { -1.0 };
            let d = INNER - depth / 2.0 - 0.02;
            let (offset, yaw) = match rng.index(4) {
                0 => (Vec2::new(t, -d), 0.0),
                1 => (Vec2::new(t, d), PI),
                2 => (Vec2::new(d, t), -FRAC_PI_2),
                _ => (Vec2::new(-d, t), FRAC_PI_2),
            };
            let half = footprint(width, depth, yaw);
            let c = Vec2::new(room.x + offset.x, room.z + offset.y);
            if self.free(c, half) {
                self.reserve(c, half);
                return Some((Vec3::new(c.x, 0.0, c.y), yaw));
            }
        }
        None
    }

    /// Un emplacement dans un coin de la pièce.
    pub fn corner_spot(&mut self, rng: &mut Rng, room: Vec3, radius: f32) -> Option<Vec3> {
        let d = INNER - radius - 0.1;
        for _ in 0..8 {
            let sx = if rng.chance(0.5) { 1.0 } else { -1.0 };
            let sz = if rng.chance(0.5) { 1.0 } else { -1.0 };
            let c = Vec2::new(room.x + sx * (d - rng.range(0.0, 0.5)), room.z + sz * (d - rng.range(0.0, 0.5)));
            let half = Vec2::splat(radius);
            if self.free(c, half) {
                self.reserve(c, half);
                return Some(Vec3::new(c.x, 0.0, c.y));
            }
        }
        None
    }
}

/// Ambiance d'une pièce : sol, murs et mobilier.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Theme {
    Warehouse,
    Office,
    Lounge,
    Boiler,
}

impl Theme {
    pub fn floor(self) -> (Tex, Color) {
        match self {
            Theme::Warehouse => (Tex::Concrete, Color::srgb(0.75, 0.75, 0.78)),
            Theme::Office => (Tex::Tile, Color::srgb(0.85, 0.88, 0.9)),
            Theme::Lounge => (Tex::Carpet, Color::srgb(0.45, 0.2, 0.22)),
            Theme::Boiler => (Tex::Metal, Color::srgb(0.6, 0.62, 0.65)),
        }
    }

    pub fn wall(self) -> (Tex, Color) {
        match self {
            Theme::Warehouse => (Tex::Brick, Color::srgb(0.8, 0.72, 0.68)),
            Theme::Office => (Tex::Plaster, Color::srgb(0.62, 0.78, 0.7)),
            Theme::Lounge => (Tex::Plaster, Color::srgb(0.85, 0.7, 0.55)),
            Theme::Boiler => (Tex::Concrete, Color::srgb(0.6, 0.58, 0.55)),
        }
    }

    pub fn random(rng: &mut Rng) -> Theme {
        [Theme::Warehouse, Theme::Office, Theme::Lounge, Theme::Boiler][rng.index(4)]
    }
}

/// Meuble une pièce. Renvoie les emplacements d'étagère disponibles pour y poser des objets.
pub fn furnish(cx: &mut Ctx, rng: &mut Rng, theme: Theme, room: Vec3, placer: &mut Placer, busy: bool) -> Vec<Vec3> {
    let mut slots = Vec::new();
    // Peu de teintes différentes : les matériaux sont ainsi partagés entre tous les meubles.
    let wood = |rng: &mut Rng| {
        [
            Color::srgb(0.85, 0.65, 0.45),
            Color::srgb(0.7, 0.55, 0.4),
            Color::srgb(0.95, 0.8, 0.55),
            Color::srgb(0.6, 0.45, 0.35),
        ][rng.index(4)]
    };
    let paint = |rng: &mut Rng| {
        [
            Color::srgb(0.7, 0.2, 0.15),
            Color::srgb(0.2, 0.35, 0.65),
            Color::srgb(0.25, 0.5, 0.3),
            Color::srgb(0.75, 0.6, 0.15),
        ][rng.index(4)]
    };
    // La pièce de départ est plus dégagée.
    let count = |rng: &mut Rng, lo: usize, hi: usize| if busy { lo + rng.index(hi - lo + 1) } else { lo };

    match theme {
        Theme::Warehouse => {
            for _ in 0..count(rng, 1, 3) {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 2.0, 0.5) {
                    let tint = wood(rng);
                    slots.extend(cx.shelf(p, yaw, tint));
                }
            }
            for _ in 0..count(rng, 1, 3) {
                if let Some(p) = placer.corner_spot(rng, room, 0.3) {
                    let tint = paint(rng);
                    cx.barrel(p, tint);
                }
            }
            if busy && rng.chance(0.3) {
                if let Some(p) = placer.corner_spot(rng, room, 0.3) {
                    cx.pillar(p);
                }
            }
        }
        Theme::Office => {
            for _ in 0..count(rng, 1, 2) {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 1.6, 0.8) {
                    let tint = wood(rng);
                    cx.desk(p, yaw, tint);
                }
            }
            for _ in 0..count(rng, 1, 3) {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 0.5, 0.5) {
                    cx.locker(p, yaw, Color::srgb(0.45, 0.55, 0.5));
                }
            }
            if let Some((p, yaw)) = placer.wall_spot(rng, room, 2.0, 0.5) {
                let tint = wood(rng);
                slots.extend(cx.shelf(p, yaw, tint));
            }
        }
        Theme::Lounge => {
            let rug_tint = [Color::srgb(0.6, 0.2, 0.2), Color::srgb(0.2, 0.3, 0.55), Color::srgb(0.25, 0.45, 0.3)][rng.index(3)];
            cx.rug(room, if rng.chance(0.5) { 0.0 } else { FRAC_PI_2 }, rug_tint);
            if let Some((p, yaw)) = placer.wall_spot(rng, room, 1.8, 0.8) {
                let tint = [Color::srgb(0.5, 0.3, 0.25), Color::srgb(0.25, 0.35, 0.5), Color::srgb(0.3, 0.45, 0.35)][rng.index(3)];
                cx.sofa(p, yaw, tint);
            }
            for _ in 0..count(rng, 1, 2) {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 2.0, 0.5) {
                    let tint = Color::srgb(0.55, 0.38, 0.25);
                    slots.extend(cx.shelf(p, yaw, tint));
                }
            }
            if let Some((p, yaw)) = placer.wall_spot(rng, room, 1.0, 0.6) {
                let tint = wood(rng);
                cx.desk(p, yaw, tint);
            }
        }
        Theme::Boiler => {
            for _ in 0..count(rng, 1, 2) {
                if let Some(p) = placer.corner_spot(rng, room, 0.6) {
                    let tint = [Color::srgb(0.5, 0.55, 0.6), Color::srgb(0.6, 0.4, 0.3)][rng.index(2)];
                    cx.tank(p, tint);
                }
            }
            for _ in 0..count(rng, 1, 2) {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 0.5, 0.5) {
                    cx.locker(p, yaw, Color::srgb(0.35, 0.4, 0.45));
                }
            }
            for _ in 0..count(rng, 1, 2) {
                if let Some(p) = placer.corner_spot(rng, room, 0.3) {
                    let tint = paint(rng);
                    cx.barrel(p, tint);
                }
            }
            if busy {
                if let Some((p, yaw)) = placer.wall_spot(rng, room, 2.0, 0.5) {
                    let tint = wood(rng);
                    slots.extend(cx.shelf(p, yaw, tint));
                }
            }
            let rust = Color::srgb(0.62, 0.42, 0.32);
            for off in [-3.0, 0.0, 3.0] {
                if rng.chance(0.6) {
                    cx.pipe(Vec3::new(room.x + off, 3.55, room.z), false, rust);
                }
            }
            if rng.chance(0.6) {
                cx.pipe(Vec3::new(room.x, 3.3, room.z + rng.range(-3.0, 3.0)), true, Color::srgb(0.5, 0.55, 0.6));
            }
        }
    }
    slots
}

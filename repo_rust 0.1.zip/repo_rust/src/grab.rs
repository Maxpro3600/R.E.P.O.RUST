//! Attraper, déplacer et lancer des objets.
//!
//! Clic droit maintenu : attraper. Molette : distance. Clic gauche : lancer.
//! L'objet n'est pas « collé » à la caméra : on lui impose une vitesse vers un
//! point devant nous. Il reste un vrai objet physique (il bute sur les murs,
//! les plus lourds sont plus lents à traîner, la Force améliore tout ça).

use avian3d::prelude::*;
use bevy::input::mouse::AccumulatedMouseScroll;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, CursorOptions, PrimaryWindow};

use crate::common::*;
use crate::game::{GameState, Run};
use crate::interact::Interactable;
use crate::player::{Player, PlayerCamera, Stamina};

const REACH: f32 = 4.0;
const INTERACT_REACH: f32 = 3.0;
const MIN_DISTANCE: f32 = 1.2;
const PULL_STRENGTH: f32 = 12.0;
const THROW_COST: f32 = 15.0;

/// Objet qu'on peut attraper.
#[derive(Component)]
pub struct Grabbable;

/// Marqueur : l'objet est actuellement tenu.
#[derive(Component)]
pub struct Grabbed;

#[derive(Resource, Default)]
pub struct Held {
    pub entity: Option<Entity>,
    pub distance: f32,
}

/// Ce que vise le réticule (pour l'interface et les interactions).
#[derive(Resource, Default)]
pub struct Looking {
    pub grab: Option<Entity>,
    pub interact: Option<Entity>,
}

pub struct GrabPlugin;

impl Plugin for GrabPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<Held>()
            .init_resource::<Looking>()
            .add_systems(Update, pick_and_drop.run_if(in_state(GameState::Playing)))
            // Avant la physique, pour que la vitesse imposée soit prise en compte au pas courant.
            .add_systems(FixedUpdate, drag_held.run_if(in_state(GameState::Playing)));
    }
}

#[allow(clippy::too_many_arguments)]
fn pick_and_drop(
    mut commands: Commands,
    mouse: Res<ButtonInput<MouseButton>>,
    scroll: Res<AccumulatedMouseScroll>,
    run: Res<Run>,
    spatial: SpatialQuery,
    camera: Single<&GlobalTransform, With<PlayerCamera>>,
    player: Single<(Entity, &mut Stamina), With<Player>>,
    cursor: Single<&CursorOptions, With<PrimaryWindow>>,
    grabbables: Query<(), With<Grabbable>>,
    interactables: Query<(), With<Interactable>>,
    mut bodies: Query<(&mut LinearVelocity, &Mass)>,
    mut held: ResMut<Held>,
    mut looking: ResMut<Looking>,
    mut sfx: MessageWriter<PlaySfx>,
    mut noise: MessageWriter<Noise>,
) {
    let (player_entity, mut stamina) = player.into_inner();

    // L'objet tenu a pu être détruit (extraction, changement de niveau...).
    if let Some(e) = held.entity {
        if !grabbables.contains(e) {
            held.entity = None;
        }
    }

    // Rayon depuis les yeux, droit devant.
    let filter = SpatialQueryFilter::from_excluded_entities([player_entity]);
    let hit = spatial.cast_ray(camera.translation(), camera.forward(), REACH, true, &filter);
    looking.grab = hit.as_ref().map(|h| h.entity).filter(|e| grabbables.contains(*e));
    looking.interact = hit
        .as_ref()
        .filter(|h| h.distance <= INTERACT_REACH)
        .map(|h| h.entity)
        .filter(|e| interactables.contains(*e));

    if held.entity.is_none() && mouse.just_pressed(MouseButton::Right) {
        if let (Some(target), Some(hit)) = (looking.grab, hit) {
            held.entity = Some(target);
            held.distance = hit.distance.max(MIN_DISTANCE);
            // Tenu en main : jamais endormi, et ignoré par la détection de chocs.
            commands
                .entity(target)
                .remove::<Sleeping>()
                .insert((Grabbed, SleepingDisabled));
            sfx.write(PlaySfx::flat(Sfx::Grab, 0.7));
        }
    }

    let Some(e) = held.entity else { return };
    held.distance = (held.distance + scroll.delta.y * 0.3).clamp(MIN_DISTANCE, REACH);

    let locked = cursor.grab_mode != CursorGrabMode::None;
    if locked && mouse.just_pressed(MouseButton::Left) && stamina.current >= 10.0 {
        // Lancer : plus l'objet est lourd, moins il part vite.
        if let Ok((mut velocity, mass)) = bodies.get_mut(e) {
            let speed = 16.0 * run.strength_mult() / (1.0 + mass.0 / 12.0);
            velocity.0 = camera.forward().as_vec3() * speed.clamp(3.0, 22.0);
        }
        stamina.current -= THROW_COST;
        commands.entity(e).remove::<(Grabbed, SleepingDisabled)>();
        held.entity = None;
        sfx.write(PlaySfx::flat(Sfx::Throw, 0.8));
        noise.write(Noise { pos: camera.translation(), radius: 8.0 });
    } else if !mouse.pressed(MouseButton::Right) {
        commands.entity(e).remove::<(Grabbed, SleepingDisabled)>();
        held.entity = None;
        sfx.write(PlaySfx::flat(Sfx::Release, 0.5));
    }
}

fn drag_held(
    held: Res<Held>,
    run: Res<Run>,
    camera: Single<&GlobalTransform, With<PlayerCamera>>,
    mut bodies: Query<(&Transform, &mut LinearVelocity, &mut AngularVelocity, &Mass)>,
) {
    let Some(entity) = held.entity else { return };
    let Ok((transform, mut velocity, mut angular, mass)) = bodies.get_mut(entity) else {
        return;
    };

    let target = camera.translation() + camera.forward() * held.distance;
    let to_target = target - transform.translation;

    // Plus l'objet est lourd, plus il est lent à amener : la statue se traîne, le vase vole.
    let max_speed = (12.0 * run.strength_mult() / (1.0 + mass.0 / 15.0)).max(1.5);
    velocity.0 = (to_target * PULL_STRENGTH).clamp_length_max(max_speed);
    angular.0 *= 0.85; // calme les rotations pour qu'il ne tourbillonne pas
}

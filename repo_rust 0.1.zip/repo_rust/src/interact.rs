//! Interactions (touche E) : le terminal du camion termine le niveau.

use bevy::prelude::*;

use crate::common::*;
use crate::game::{GameState, Run};
use crate::grab::Looking;

#[derive(Component, Clone, Copy, PartialEq)]
pub enum Interactable {
    /// Termine le niveau une fois toutes les extractions faites.
    Truck,
}

pub struct InteractPlugin;

impl Plugin for InteractPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, interact.run_if(in_state(GameState::Playing)));
    }
}

fn interact(
    keys: Res<ButtonInput<KeyCode>>,
    looking: Res<Looking>,
    targets: Query<&Interactable>,
    mut run: ResMut<Run>,
    mut sfx: MessageWriter<PlaySfx>,
    mut toasts: MessageWriter<Toast>,
    mut next: ResMut<NextState<GameState>>,
) {
    if !keys.just_pressed(KeyCode::KeyE) {
        return;
    }
    let Some(entity) = looking.interact else { return };
    let Ok(Interactable::Truck) = targets.get(entity) else { return };

    if run.all_extracted() {
        run.money += run.banked;
        run.needs_level = true;
        sfx.write(PlaySfx::flat(Sfx::Buy, 0.8));
        next.set(GameState::Shop);
    } else {
        sfx.write(PlaySfx::flat(Sfx::Error, 0.6));
        toasts.write(Toast(format!(
            "Il reste {} extraction(s) à faire.",
            run.extractions_total - run.extractions_done
        )));
    }
}

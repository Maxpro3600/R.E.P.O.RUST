//! Objets de valeur : ils perdent de la valeur quand on les cogne.

use avian3d::prelude::*;
use bevy::color::Mix;
use bevy::prelude::*;

use crate::common::*;
use crate::grab::Grabbable;
use crate::impact::Impactor;
use crate::textures::{Gfx, Tex};

/// Choc (m/s) en dessous duquel un objet ne perd rien.
const IMPACT_THRESHOLD: f32 = 3.0;
/// Part de la valeur maximale perdue par m/s au-dessus du seuil (avant fragilité).
const DAMAGE_PER_MS: f32 = 0.04;

#[derive(Component)]
pub struct Valuable {
    pub value: f32,
    pub max_value: f32,
    /// 1.0 = normal, plus haut = plus fragile.
    pub fragility: f32,
    base_color: Color,
}

pub struct ValuableSpec<'a> {
    pub name: &'a str,
    pub size: Vec3,
    pub mass: f32,
    pub value: f32,
    pub fragility: f32,
    pub color: Color,
    pub tex: Tex,
}

pub struct ValuablesPlugin;

impl Plugin for ValuablesPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, (valuable_impacts, update_valuable_color));
    }
}

pub fn spawn_valuable(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    materials: &mut Assets<StandardMaterial>,
    gfx: &mut Gfx,
    spec: ValuableSpec,
    pos: Vec3,
) {
    let s = spec.size;
    commands.spawn((
        LevelEntity,
        Name::new(spec.name.to_string()),
        Valuable {
            value: spec.value,
            max_value: spec.value,
            fragility: spec.fragility,
            base_color: spec.color,
        },
        Grabbable,
        Impactor::default(),
        Mesh3d(gfx.box_mesh(meshes, s, 0.6)),
        // Un matériau par objet pour pouvoir le faire rougir individuellement.
        MeshMaterial3d(materials.add(gfx.standard(spec.tex, spec.color))),
        Transform::from_translation(pos),
        RigidBody::Dynamic,
        Collider::cuboid(s.x, s.y, s.z),
        Mass(spec.mass),
        Restitution::new(0.1),
    ));
}

/// Dégâts = intensité du choc au-delà du seuil, selon la fragilité de l'objet.
fn valuable_impacts(
    mut impacts: MessageReader<Impact>,
    mut q: Query<(&mut Valuable, &Name)>,
    mut sfx: MessageWriter<PlaySfx>,
    mut toasts: MessageWriter<Toast>,
) {
    for impact in impacts.read() {
        let Ok((mut valuable, name)) = q.get_mut(impact.entity) else { continue };
        if impact.strength <= IMPACT_THRESHOLD || valuable.value <= 0.0 {
            continue;
        }
        let loss = (impact.strength - IMPACT_THRESHOLD)
            * DAMAGE_PER_MS
            * valuable.max_value
            * valuable.fragility;
        if loss <= 0.0 {
            continue;
        }
        let before = valuable.value;
        valuable.value = (before - loss).max(0.0);
        if valuable.value <= 0.0 {
            sfx.write(PlaySfx::at(Sfx::Glass, impact.pos, 1.0));
            toasts.write(Toast(format!("{name} est détruit !")));
        } else if before - valuable.value >= 40.0 {
            toasts.write(Toast(format!("{name} : -{:.0} $", before - valuable.value)));
        }
    }
}

/// L'objet rougit à mesure qu'il perd de la valeur.
fn update_valuable_color(
    valuables: Query<(&Valuable, &MeshMaterial3d<StandardMaterial>), Changed<Valuable>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let damaged = Color::srgb(0.5, 0.05, 0.05);
    for (valuable, handle) in &valuables {
        if let Some(mut material) = materials.get_mut(&handle.0) {
            let lost = 1.0 - valuable.value / valuable.max_value;
            material.base_color = valuable.base_color.mix(&damaged, lost);
        }
    }
}

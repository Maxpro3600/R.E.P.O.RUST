//! Application des dégâts, mort du joueur, flash rouge.

use bevy::prelude::*;

use crate::common::*;
use crate::game::GameState;
use crate::player::Player;

/// Intensité du flash rouge à l'écran (0 à 1), qui s'estompe tout seul.
#[derive(Resource, Default)]
pub struct HurtFlash(pub f32);

pub struct CombatPlugin;

impl Plugin for CombatPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<HurtFlash>()
            .add_systems(Update, apply_damage.run_if(in_state(GameState::Playing)));
    }
}

fn apply_damage(
    mut messages: MessageReader<Damage>,
    mut healths: Query<&mut Health>,
    players: Query<(), With<Player>>,
    mut flash: ResMut<HurtFlash>,
    mut sfx: MessageWriter<PlaySfx>,
    mut next: ResMut<NextState<GameState>>,
) {
    for damage in messages.read() {
        let Ok(mut health) = healths.get_mut(damage.target) else { continue };
        if health.current <= 0.0 {
            continue;
        }
        health.current -= damage.amount;
        if players.contains(damage.target) {
            flash.0 = (flash.0 + damage.amount / 40.0).clamp(0.45, 1.0);
            sfx.write(PlaySfx::flat(Sfx::Hurt, 0.9));
            if health.current <= 0.0 {
                sfx.write(PlaySfx::flat(Sfx::Death, 1.0));
                next.set(GameState::Dead);
            }
        }
    }
}

//! Grille de navigation (plan 2D) et recherche de chemin A* pour les monstres.

use bevy::prelude::*;
use std::cmp::Reverse;
use std::collections::BinaryHeap;

#[derive(Resource, Default)]
pub struct NavGrid {
    min: Vec2,
    cell: f32,
    w: i32,
    h: i32,
    blocked: Vec<bool>,
    /// Centre de chaque pièce : destinations de patrouille.
    pub room_centers: Vec<Vec3>,
}

const DIRS: [(i32, i32, i32); 8] = [
    (1, 0, 10),
    (-1, 0, 10),
    (0, 1, 10),
    (0, -1, 10),
    (1, 1, 14),
    (1, -1, 14),
    (-1, 1, 14),
    (-1, -1, 14),
];

impl NavGrid {
    pub fn new(min: Vec2, max: Vec2, cell: f32) -> Self {
        let w = ((max.x - min.x) / cell).ceil() as i32;
        let h = ((max.y - min.y) / cell).ceil() as i32;
        Self {
            min,
            cell,
            w,
            h,
            blocked: vec![false; (w * h) as usize],
            room_centers: Vec::new(),
        }
    }

    fn idx(&self, c: (i32, i32)) -> usize {
        (c.1 * self.w + c.0) as usize
    }

    fn in_bounds(&self, c: (i32, i32)) -> bool {
        c.0 >= 0 && c.1 >= 0 && c.0 < self.w && c.1 < self.h
    }

    fn walkable(&self, c: (i32, i32)) -> bool {
        self.in_bounds(c) && !self.blocked[self.idx(c)]
    }

    fn center_xz(&self, c: (i32, i32)) -> Vec2 {
        self.min + Vec2::new(c.0 as f32 + 0.5, c.1 as f32 + 0.5) * self.cell
    }

    fn cell_of(&self, p: Vec3) -> (i32, i32) {
        let v = (Vec2::new(p.x, p.z) - self.min) / self.cell;
        (
            (v.x.floor() as i32).clamp(0, self.w - 1),
            (v.y.floor() as i32).clamp(0, self.h - 1),
        )
    }

    /// Bloque tout ce qui touche la boîte (x, z) donnée.
    pub fn block_aabb(&mut self, center: Vec2, half: Vec2) {
        let lo = ((center - half - self.min) / self.cell).floor();
        let hi = ((center + half - self.min) / self.cell).floor();
        for cy in (lo.y as i32)..=(hi.y as i32) {
            for cx in (lo.x as i32)..=(hi.x as i32) {
                if !self.in_bounds((cx, cy)) {
                    continue;
                }
                let c = self.center_xz((cx, cy));
                if (c.x - center.x).abs() <= half.x && (c.y - center.y).abs() <= half.y {
                    let i = self.idx((cx, cy));
                    self.blocked[i] = true;
                }
            }
        }
    }

    fn nearest_free(&self, c: (i32, i32)) -> Option<(i32, i32)> {
        if self.walkable(c) {
            return Some(c);
        }
        for r in 1..=8_i32 {
            for dy in -r..=r {
                for dx in -r..=r {
                    if dx.abs().max(dy.abs()) != r {
                        continue;
                    }
                    let n = (c.0 + dx, c.1 + dy);
                    if self.walkable(n) {
                        return Some(n);
                    }
                }
            }
        }
        None
    }

    fn line_clear(&self, a: (i32, i32), b: (i32, i32)) -> bool {
        let (mut x, mut y) = a;
        let (dx, dy) = ((b.0 - a.0).abs(), -(b.1 - a.1).abs());
        let (sx, sy) = ((b.0 - a.0).signum(), (b.1 - a.1).signum());
        let mut err = dx + dy;
        loop {
            if !self.walkable((x, y)) {
                return false;
            }
            if (x, y) == b {
                return true;
            }
            let e2 = 2 * err;
            if e2 >= dy {
                err += dy;
                x += sx;
            }
            if e2 <= dx {
                err += dx;
                y += sy;
            }
        }
    }

    /// Chemin le plus court (liste de points au sol), ou `None` si inaccessible.
    pub fn path(&self, from: Vec3, to: Vec3) -> Option<Vec<Vec3>> {
        let start = self.nearest_free(self.cell_of(from))?;
        let goal = self.nearest_free(self.cell_of(to))?;
        let n = (self.w * self.h) as usize;
        let mut g = vec![i32::MAX; n];
        let mut came = vec![-1i32; n];
        let mut closed = vec![false; n];
        let mut open = BinaryHeap::new();

        let heuristic = |c: (i32, i32)| {
            let (dx, dy) = ((c.0 - goal.0).abs(), (c.1 - goal.1).abs());
            10 * (dx + dy) - 6 * dx.min(dy)
        };

        g[self.idx(start)] = 0;
        open.push((Reverse(heuristic(start)), self.idx(start) as i32));
        let mut found = false;
        while let Some((_, i)) = open.pop() {
            let i = i as usize;
            if closed[i] {
                continue;
            }
            closed[i] = true;
            let cur = ((i as i32) % self.w, (i as i32) / self.w);
            if cur == goal {
                found = true;
                break;
            }
            for (dx, dy, cost) in DIRS {
                let nb = (cur.0 + dx, cur.1 + dy);
                if !self.walkable(nb) {
                    continue;
                }
                // Pas de coupe dans un coin.
                if dx != 0 && dy != 0 && !(self.walkable((cur.0 + dx, cur.1)) && self.walkable((cur.0, cur.1 + dy))) {
                    continue;
                }
                let ni = self.idx(nb);
                let ng = g[i] + cost;
                if ng < g[ni] {
                    g[ni] = ng;
                    came[ni] = i as i32;
                    open.push((Reverse(ng + heuristic(nb)), ni as i32));
                }
            }
        }
        if !found {
            return None;
        }

        let mut cells = vec![goal];
        let mut i = self.idx(goal);
        while came[i] >= 0 {
            i = came[i] as usize;
            cells.push(((i as i32) % self.w, (i as i32) / self.w));
        }
        cells.reverse();

        // Lissage : on saute les points intermédiaires quand la ligne droite est dégagée.
        let mut out = Vec::new();
        let mut a = 0;
        while a < cells.len() - 1 {
            let mut b = (a + 40).min(cells.len() - 1);
            while b > a + 1 && !self.line_clear(cells[a], cells[b]) {
                b -= 1;
            }
            let c = self.center_xz(cells[b]);
            out.push(Vec3::new(c.x, 0.0, c.y));
            a = b;
        }
        if out.is_empty() {
            let c = self.center_xz(goal);
            out.push(Vec3::new(c.x, 0.0, c.y));
        }
        Some(out)
    }
}

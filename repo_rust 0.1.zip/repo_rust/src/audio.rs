//! Sons : bibliothèque d'effets, lecture spatialisée, ambiance, battements de cœur.
//!
//! Tous les sons sont générés par `tools/gen_sounds.py` (rien n'est tiré du vrai jeu).

use std::collections::HashMap;

use bevy::audio::Volume;
use bevy::prelude::*;

use crate::common::*;
use crate::game::GameState;
use crate::player::Player;

#[derive(Resource)]
struct SoundBank(HashMap<Sfx, Handle<AudioSource>>);

#[derive(Resource, Default)]
struct HeartbeatTimer(f32);

pub struct AudioFxPlugin;

impl Plugin for AudioFxPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<HeartbeatTimer>()
            .add_systems(Startup, load_sounds)
            .add_systems(Update, (play_sfx, impact_sounds))
            .add_systems(Update, heartbeat.run_if(in_state(GameState::Playing)));
    }
}

fn load_sounds(mut commands: Commands, assets: Res<AssetServer>) {
    let bank = Sfx::ALL
        .iter()
        .map(|&sfx| (sfx, assets.load(format!("sounds/{}.wav", sfx.file()))))
        .collect();
    commands.insert_resource(SoundBank(bank));

    // Nappe d'ambiance en boucle.
    commands.spawn((
        AudioPlayer::new(assets.load("sounds/ambience.wav")),
        PlaybackSettings::LOOP.with_volume(Volume::Linear(0.35)),
    ));
}

fn play_sfx(mut commands: Commands, bank: Res<SoundBank>, mut messages: MessageReader<PlaySfx>) {
    // Garde-fou : jamais plus de 10 sons nouveaux par image.
    for message in messages.read().take(10) {
        let Some(handle) = bank.0.get(&message.sfx) else { continue };
        let settings = PlaybackSettings::DESPAWN
            .with_volume(Volume::Linear(message.volume))
            .with_spatial(message.pos.is_some());
        let mut entity = commands.spawn((AudioPlayer::new(handle.clone()), settings));
        if let Some(pos) = message.pos {
            entity.insert(Transform::from_translation(pos));
        }
    }
}

/// Chaque choc fait du bruit : léger ou lourd selon son intensité.
fn impact_sounds(mut impacts: MessageReader<Impact>, mut sfx: MessageWriter<PlaySfx>) {
    for impact in impacts.read() {
        let s = impact.strength;
        let (which, volume) = if s < 4.5 {
            (Sfx::ImpactSoft, (s / 4.0).clamp(0.25, 0.8))
        } else {
            (Sfx::ImpactHard, (s / 10.0).clamp(0.5, 1.0))
        };
        sfx.write(PlaySfx::at(which, impact.pos, volume));
    }
}

/// Quand la santé est basse, le cœur s'emballe.
fn heartbeat(
    time: Res<Time>,
    health: Single<&Health, With<Player>>,
    mut timer: ResMut<HeartbeatTimer>,
    mut sfx: MessageWriter<PlaySfx>,
) {
    let fraction = health.fraction();
    if fraction >= 0.3 || health.current <= 0.0 {
        timer.0 = 0.0;
        return;
    }
    timer.0 -= time.delta_secs();
    if timer.0 <= 0.0 {
        timer.0 = 0.5 + fraction * 2.0;
        sfx.write(PlaySfx::flat(Sfx::Heartbeat, 0.9 - fraction));
    }
}

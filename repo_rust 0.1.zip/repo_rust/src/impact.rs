//! Détection des chocs : variation brutale de vitesse d'un objet physique.
//!
//! Un objet tenu en main est ignoré (c'est nous qui lui imposons sa vitesse).

use avian3d::prelude::*;
use bevy::prelude::*;

use crate::common::*;
use crate::grab::Grabbed;

/// Choc minimal (m/s) pour être signalé.
const MIN_IMPACT: f32 = 1.6;

#[derive(Component, Default)]
pub struct Impactor {
    prev: Vec3,
    cooldown: f32,
}

pub struct ImpactPlugin;

impl Plugin for ImpactPlugin {
    fn build(&self, app: &mut App) {
        // FixedLast tourne après la physique : on mesure le choc du pas qui vient de se jouer.
        app.add_systems(FixedLast, detect_impacts);
    }
}

fn detect_impacts(
    time: Res<Time>,
    mut q: Query<(Entity, &Transform, &LinearVelocity, &mut Impactor, Has<Grabbed>)>,
    mut impacts: MessageWriter<Impact>,
    mut noise: MessageWriter<Noise>,
) {
    let dt = time.delta_secs();
    for (entity, transform, velocity, mut impactor, held) in &mut q {
        let delta_v = (velocity.0 - impactor.prev).length();
        impactor.prev = velocity.0;
        impactor.cooldown = (impactor.cooldown - dt).max(0.0);
        if held || delta_v < MIN_IMPACT || impactor.cooldown > 0.0 {
            continue;
        }
        impactor.cooldown = 0.12;
        impacts.write(Impact {
            entity,
            pos: transform.translation,
            strength: delta_v,
        });
        if delta_v > 3.0 {
            noise.write(Noise {
                pos: transform.translation,
                radius: (delta_v * 2.5).min(22.0),
            });
        }
    }
}

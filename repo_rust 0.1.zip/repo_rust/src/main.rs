//! Base d'un clone de R.E.P.O. : jeu coopératif de physique à la première personne.
//!
//! Chaque fonctionnalité vit dans son propre plugin, ce qui permet de les faire
//! évoluer (ou de les brancher sur le réseau) séparément plus tard.

mod audio;
mod combat;
mod common;
mod enemy;
mod extraction;
mod game;
mod grab;
mod hud;
mod impact;
mod interact;
mod level;
mod menu;
mod nav;
mod player;
mod props;
mod rng;
mod shop;
mod textures;
mod valuables;

use avian3d::prelude::*;
use bevy::asset::AssetMetaCheck;
use bevy::prelude::*;

fn main() {
    App::new()
        .add_plugins((
            DefaultPlugins
                .set(WindowPlugin {
                    primary_window: Some(Window {
                        title: "R.E.P.O. (Rust)".into(),
                        ..default()
                    }),
                    ..default()
                })
                // Pas de fichiers .meta à chercher à chaque chargement : démarrage plus rapide.
                .set(AssetPlugin {
                    meta_check: AssetMetaCheck::Never,
                    ..default()
                }),
            PhysicsPlugins::default(),
        ))
        .add_plugins((
            common::CommonPlugin,
            textures::TexturesPlugin,
            menu::MenuPlugin,
            extraction::ExtractionPlugin,
        ))
        .add_plugins((
            game::GamePlugin,
            level::LevelPlugin,
            player::PlayerPlugin,
            grab::GrabPlugin,
            impact::ImpactPlugin,
            valuables::ValuablesPlugin,
            interact::InteractPlugin,
            enemy::EnemyPlugin,
            combat::CombatPlugin,
            audio::AudioFxPlugin,
            hud::HudPlugin,
            shop::ShopPlugin,
        ))
        .run();
}

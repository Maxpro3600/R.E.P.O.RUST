//! Joueur à la première personne : santé, endurance, déplacement, lampe torche.
//!
//! Les touches sont lues par position physique : « WASD » correspond donc
//! à ZQSD sur un clavier AZERTY, sans rien configurer.

use avian3d::prelude::*;
use bevy::anti_alias::fxaa::Fxaa;
use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, CursorOptions, PrimaryWindow};

use crate::common::*;
use crate::game::{GameState, Run};

const CAPSULE_RADIUS: f32 = 0.35;
const CAPSULE_LENGTH: f32 = 1.0; // partie cylindrique ; hauteur totale = 1,7 m
const HALF_HEIGHT: f32 = CAPSULE_LENGTH / 2.0 + CAPSULE_RADIUS;
const EYE_HEIGHT: f32 = 0.6; // au-dessus du centre de la capsule
const CROUCH_DROP: f32 = 0.45;

const WALK_SPEED: f32 = 4.0;
const SPRINT_SPEED: f32 = 7.0;
const CROUCH_SPEED: f32 = 2.0;
const JUMP_SPEED: f32 = 5.0;
const MOUSE_SENSITIVITY: f32 = 0.0022;
const PACK_HEAL: f32 = 40.0;

#[derive(Component)]
pub struct Player;

#[derive(Component)]
pub struct PlayerCamera;

#[derive(Component)]
struct Flashlight;

/// Orientation du regard : on garde les angles plutôt que de relire un quaternion.
#[derive(Component, Default)]
struct LookAngles {
    yaw: f32,
    pitch: f32,
}

#[derive(Component)]
pub struct Stamina {
    pub current: f32,
    pub max: f32,
    regen_delay: f32,
}

#[derive(Component, Default)]
pub struct PlayerState {
    pub crouching: bool,
    grounded: bool,
    prev_vy: f32,
    step_timer: f32,
    step_flip: bool,
}

pub struct PlayerPlugin;

impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, spawn_player)
            .add_systems(OnEnter(GameState::Playing), refresh_stats)
            .add_systems(Update, camera_height)
            .add_systems(
                Update,
                (mouse_look, toggle_flashlight, use_health_pack, recapture_cursor).run_if(in_state(GameState::Playing)),
            )
            .add_systems(FixedUpdate, movement.run_if(in_state(GameState::Playing)));
    }
}

fn spawn_player(mut commands: Commands) {
    commands
        .spawn((
            Name::new("Joueur"),
            Player,
            LookAngles::default(),
            Health::new(100.0),
            Stamina { current: 100.0, max: 100.0, regen_delay: 0.0 },
            PlayerState::default(),
            Transform::from_xyz(0.0, 1.0, 0.0),
            RigidBody::Dynamic,
            Collider::capsule(CAPSULE_RADIUS, CAPSULE_LENGTH),
            // Le joueur ne bascule jamais et ne s'endort jamais.
            LockedAxes::ROTATION_LOCKED,
            SleepingDisabled,
            // Pas de friction : on contrôle la vitesse nous-mêmes (sinon on « colle » aux murs).
            Friction::ZERO.with_combine_rule(CoefficientCombine::Min),
            Mass(80.0),
            // Lisse l'affichage entre deux pas de physique.
            TransformInterpolation,
        ))
        .with_children(|parent| {
            parent
                .spawn((
                    PlayerCamera,
                    Camera3d::default(),
                    // MSAA coûte cher sur un portable : on le remplace par FXAA, bien plus léger.
                    Msaa::Off,
                    Fxaa::default(),
                    Projection::from(PerspectiveProjection {
                        fov: 80.0_f32.to_radians(),
                        ..default()
                    }),
                    // Les sons sont spatialisés depuis la position de la caméra.
                    SpatialListener::new(0.4),
                    Transform::from_xyz(0.0, EYE_HEIGHT, 0.0),
                ))
                .with_children(|cam| {
                    // Lampe torche : un projecteur qui suit le regard (F pour l'éteindre).
                    cam.spawn((
                        Flashlight,
                        SpotLight {
                            intensity: 1_800_000.0,
                            range: 28.0,
                            inner_angle: 0.25,
                            outer_angle: 0.6,
                            shadow_maps_enabled: true,
                            color: Color::srgb(1.0, 0.96, 0.88),
                            ..default()
                        },
                        Transform::default(),
                    ));
                });
        });
}

/// Au début de chaque niveau : met à jour les maxima selon les améliorations.
fn refresh_stats(
    mut run: ResMut<Run>,
    mut player: Single<(&mut Health, &mut Stamina), With<Player>>,
) {
    let (health, stamina) = &mut *player;
    health.max = run.max_health();
    stamina.max = run.max_stamina();
    stamina.current = stamina.max;
    if run.fresh {
        health.current = health.max;
        run.fresh = false;
    }
    health.current = health.current.min(health.max);
}

/// En jeu, un clic recapture la souris si elle a été libérée (par exemple après un Alt-Tab).
fn recapture_cursor(
    mut cursor: Single<&mut CursorOptions, With<PrimaryWindow>>,
    mouse: Res<ButtonInput<MouseButton>>,
) {
    if mouse.just_pressed(MouseButton::Left) && cursor.grab_mode == CursorGrabMode::None {
        cursor.grab_mode = CursorGrabMode::Locked;
        cursor.visible = false;
    }
}

fn mouse_look(
    motion: Res<AccumulatedMouseMotion>,
    cursor: Single<&CursorOptions, With<PrimaryWindow>>,
    mut player: Single<&mut LookAngles, With<Player>>,
    mut camera: Single<&mut Transform, With<PlayerCamera>>,
) {
    if cursor.grab_mode == CursorGrabMode::None {
        return;
    }
    player.yaw -= motion.delta.x * MOUSE_SENSITIVITY;
    player.pitch = (player.pitch - motion.delta.y * MOUSE_SENSITIVITY).clamp(-1.5, 1.5);
    camera.rotation = Quat::from_euler(EulerRot::YXZ, player.yaw, player.pitch, 0.0);
}

/// La caméra descend en douceur quand on s'accroupit.
fn camera_height(
    time: Res<Time>,
    state: Single<&PlayerState, With<Player>>,
    mut camera: Single<&mut Transform, With<PlayerCamera>>,
) {
    let target = if state.crouching { EYE_HEIGHT - CROUCH_DROP } else { EYE_HEIGHT };
    let t = (12.0 * time.delta_secs()).min(1.0);
    camera.translation.y += (target - camera.translation.y) * t;
}

fn toggle_flashlight(
    keys: Res<ButtonInput<KeyCode>>,
    mut light: Single<&mut Visibility, With<Flashlight>>,
    mut sfx: MessageWriter<PlaySfx>,
) {
    if keys.just_pressed(KeyCode::KeyF) {
        **light = if **light == Visibility::Hidden { Visibility::Inherited } else { Visibility::Hidden };
        sfx.write(PlaySfx::flat(Sfx::Flashlight, 0.5));
    }
}

/// H : utiliser un pack de soin acheté à la boutique.
fn use_health_pack(
    keys: Res<ButtonInput<KeyCode>>,
    mut run: ResMut<Run>,
    mut health: Single<&mut Health, With<Player>>,
    mut sfx: MessageWriter<PlaySfx>,
    mut toasts: MessageWriter<Toast>,
) {
    if !keys.just_pressed(KeyCode::KeyH) {
        return;
    }
    if run.packs == 0 {
        toasts.write(Toast("Aucun pack de soin (à acheter à la boutique).".into()));
    } else if health.current >= health.max {
        toasts.write(Toast("Santé déjà au maximum.".into()));
    } else {
        run.packs -= 1;
        health.current = (health.current + PACK_HEAL).min(health.max);
        sfx.write(PlaySfx::flat(Sfx::Heal, 0.8));
    }
}

#[allow(clippy::too_many_arguments)]
fn movement(
    time: Res<Time>,
    keys: Res<ButtonInput<KeyCode>>,
    run: Res<Run>,
    spatial: SpatialQuery,
    mut player: Single<
        (Entity, &Transform, &mut LinearVelocity, &LookAngles, &mut Stamina, &mut PlayerState),
        With<Player>,
    >,
    mut sfx: MessageWriter<PlaySfx>,
    mut noise: MessageWriter<Noise>,
    mut damage: MessageWriter<Damage>,
) {
    let dt = time.delta_secs();
    let (entity, transform, velocity, angles, stamina, state) = &mut *player;

    // Au sol ? Un rayon vers le bas, en ignorant le joueur lui-même.
    let filter = SpatialQueryFilter::from_excluded_entities([*entity]);
    let grounded = spatial
        .cast_ray(transform.translation, Dir3::NEG_Y, HALF_HEIGHT + 0.1, true, &filter)
        .is_some();
    let pos = transform.translation;

    // Atterrissage : bruit, son, et dégâts de chute si c'est violent.
    if grounded && !state.grounded {
        let fall = -(velocity.y.min(state.prev_vy));
        if fall > 3.0 {
            sfx.write(PlaySfx::flat(Sfx::Land, (fall / 10.0).clamp(0.3, 1.0)));
            noise.write(Noise { pos, radius: 5.0 + fall });
        }
        if fall > 9.0 {
            damage.write(Damage { target: *entity, amount: (fall - 9.0) * 7.0 });
        }
    }
    state.grounded = grounded;
    state.prev_vy = velocity.y;

    // Direction voulue, à plat, dans le repère du regard.
    let yaw = Quat::from_rotation_y(angles.yaw);
    let (forward, right) = (yaw * Vec3::NEG_Z, yaw * Vec3::X);
    let axis = |plus: KeyCode, minus: KeyCode| f32::from(keys.pressed(plus)) - f32::from(keys.pressed(minus));
    let wish = (forward * axis(KeyCode::KeyW, KeyCode::KeyS) + right * axis(KeyCode::KeyD, KeyCode::KeyA))
        .normalize_or_zero();
    let moving = wish != Vec3::ZERO;

    state.crouching = keys.pressed(KeyCode::ControlLeft) || keys.pressed(KeyCode::KeyC);
    let sprinting = moving && keys.pressed(KeyCode::ShiftLeft) && stamina.current > 1.0 && !state.crouching;

    let speed_mult = run.speed_mult();
    let speed = if state.crouching {
        CROUCH_SPEED
    } else if sprinting {
        SPRINT_SPEED * speed_mult
    } else {
        WALK_SPEED * speed_mult
    };
    let target = wish * speed;

    // Endurance : la course l'épuise, elle revient après une courte pause.
    if sprinting {
        stamina.current = (stamina.current - 20.0 * dt).max(0.0);
        stamina.regen_delay = 1.0;
    } else {
        stamina.regen_delay -= dt;
        if stamina.regen_delay <= 0.0 {
            stamina.current = (stamina.current + 15.0 * dt).min(stamina.max);
        }
    }

    // Accélération rapide au sol, contrôle réduit en l'air.
    let responsiveness = if grounded { 14.0 } else { 3.0 };
    let t = (responsiveness * dt).min(1.0);
    velocity.x += (target.x - velocity.x) * t;
    velocity.z += (target.z - velocity.z) * t;

    if grounded && keys.pressed(KeyCode::Space) && !state.crouching && stamina.current >= 8.0 {
        velocity.y = JUMP_SPEED;
        stamina.current -= 8.0;
        stamina.regen_delay = 1.0;
        sfx.write(PlaySfx::flat(Sfx::Jump, 0.5));
        noise.write(Noise { pos, radius: 7.0 });
    }

    // Pas : un son et un bruit que les monstres peuvent entendre.
    if grounded && Vec2::new(velocity.x, velocity.z).length() > 1.0 {
        state.step_timer -= dt;
        if state.step_timer <= 0.0 {
            let (interval, radius, volume) = if state.crouching {
                (0.7, 2.0, 0.25)
            } else if sprinting {
                (0.32, 13.0, 0.7)
            } else {
                (0.5, 6.0, 0.45)
            };
            state.step_timer = interval;
            state.step_flip = !state.step_flip;
            let which = if state.step_flip { Sfx::Step1 } else { Sfx::Step2 };
            sfx.write(PlaySfx::flat(which, volume));
            noise.write(Noise { pos, radius });
        }
    } else {
        state.step_timer = 0.0;
    }
}

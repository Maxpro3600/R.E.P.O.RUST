//! Textures et matériaux : bibliothèque partagée, boîtes à UV « monde », mipmaps.
//!
//! Les images sont générées par `tools/gen_textures.py`. Les maillages de boîtes et
//! les matériaux sont mis en cache : un mur de plus ne crée ni maillage ni matériau neuf,
//! ce qui accélère nettement la génération des niveaux.

use std::collections::{HashMap, HashSet};

use bevy::asset::AssetEvent;
use bevy::image::{
    ImageAddressMode, ImageFilterMode, ImageLoaderSettings, ImageSampler, ImageSamplerDescriptor,
};
use bevy::mesh::VertexAttributeValues;
use bevy::prelude::*;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Tex {
    Concrete,
    Plaster,
    Brick,
    Tile,
    Wood,
    Metal,
    Carpet,
    Ceiling,
}

impl Tex {
    pub const ALL: [Tex; 8] = [
        Tex::Concrete,
        Tex::Plaster,
        Tex::Brick,
        Tex::Tile,
        Tex::Wood,
        Tex::Metal,
        Tex::Carpet,
        Tex::Ceiling,
    ];

    fn file(self) -> &'static str {
        match self {
            Tex::Concrete => "concrete",
            Tex::Plaster => "plaster",
            Tex::Brick => "brick",
            Tex::Tile => "tile",
            Tex::Wood => "wood",
            Tex::Metal => "metal",
            Tex::Carpet => "carpet",
            Tex::Ceiling => "ceiling",
        }
    }

    fn roughness(self) -> f32 {
        match self {
            Tex::Concrete | Tex::Plaster | Tex::Brick | Tex::Ceiling => 0.92,
            Tex::Tile => 0.35,
            Tex::Wood => 0.75,
            Tex::Metal => 0.42,
            Tex::Carpet => 1.0,
        }
    }

    /// Côté (en mètres) d'une répétition de la texture : fixe l'échelle sur les murs, sols...
    pub fn tile_meters(self) -> f32 {
        match self {
            Tex::Concrete | Tex::Plaster | Tex::Ceiling | Tex::Tile => 2.0,
            Tex::Brick => 1.5,
            Tex::Wood | Tex::Metal | Tex::Carpet => 1.0,
        }
    }
}

#[derive(Resource, Default)]
pub struct Gfx {
    textures: HashMap<Tex, (Handle<Image>, Handle<Image>)>,
    ids: HashSet<AssetId<Image>>,
    boxes: HashMap<[i32; 4], Handle<Mesh>>,
    shapes: HashMap<String, Handle<Mesh>>,
    materials: HashMap<(Tex, [u8; 3]), Handle<StandardMaterial>>,
}

impl Gfx {
    /// Matériau (non ajouté aux assets) : texture + relief + teinte.
    pub fn standard(&self, tex: Tex, tint: Color) -> StandardMaterial {
        let mut material = StandardMaterial {
            base_color: tint,
            perceptual_roughness: tex.roughness(),
            ..default()
        };
        if let Some((color, normal)) = self.textures.get(&tex) {
            material.base_color_texture = Some(color.clone());
            material.normal_map_texture = Some(normal.clone());
        }
        material
    }

    /// Matériau partagé et mis en cache.
    pub fn material(
        &mut self,
        materials: &mut Assets<StandardMaterial>,
        tex: Tex,
        tint: Color,
    ) -> Handle<StandardMaterial> {
        let c = tint.to_srgba();
        let key = (tex, [(c.red * 255.0) as u8, (c.green * 255.0) as u8, (c.blue * 255.0) as u8]);
        if let Some(handle) = self.materials.get(&key) {
            return handle.clone();
        }
        let handle = materials.add(self.standard(tex, tint));
        self.materials.insert(key, handle.clone());
        handle
    }

    /// Forme quelconque mise en cache sous un nom (cylindres, etc.).
    pub fn shape(&mut self, meshes: &mut Assets<Mesh>, key: &str, make: impl FnOnce() -> Mesh) -> Handle<Mesh> {
        if let Some(handle) = self.shapes.get(key) {
            return handle.clone();
        }
        let handle = meshes.add(make());
        self.shapes.insert(key.to_string(), handle.clone());
        handle
    }

    /// Boîte dont les UV suivent les dimensions réelles : la texture garde la même échelle
    /// sur un mur de 12 m comme sur une caisse (`tile` = mètres par répétition).
    pub fn box_mesh(&mut self, meshes: &mut Assets<Mesh>, size: Vec3, tile: f32) -> Handle<Mesh> {
        let cm = |v: f32| (v * 100.0).round() as i32;
        let key = [cm(size.x), cm(size.y), cm(size.z), cm(tile)];
        if let Some(handle) = self.boxes.get(&key) {
            return handle.clone();
        }
        let mut mesh: Mesh = Cuboid::new(size.x, size.y, size.z).into();
        let positions = mesh
            .attribute(Mesh::ATTRIBUTE_POSITION)
            .and_then(VertexAttributeValues::as_float3)
            .map(|p| p.to_vec())
            .unwrap_or_default();
        let normals = mesh
            .attribute(Mesh::ATTRIBUTE_NORMAL)
            .and_then(VertexAttributeValues::as_float3)
            .map(|n| n.to_vec())
            .unwrap_or_default();
        let uvs: Vec<[f32; 2]> = positions
            .iter()
            .zip(&normals)
            .map(|(p, n)| {
                let (u, v) = if n[0].abs() > 0.5 {
                    (p[2], p[1])
                } else if n[1].abs() > 0.5 {
                    (p[0], p[2])
                } else {
                    (p[0], p[1])
                };
                [u / tile, v / tile]
            })
            .collect();
        mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
        let handle = meshes.add(mesh);
        self.boxes.insert(key, handle.clone());
        handle
    }
}

pub struct TexturesPlugin;

impl Plugin for TexturesPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<Gfx>()
            .add_systems(Startup, load_textures)
            .add_systems(Update, build_mipmaps);
    }
}

fn load_textures(mut gfx: ResMut<Gfx>, assets: Res<AssetServer>) {
    // Répétition + filtrage anisotrope : indispensable pour des sols vus de biais.
    let sampler = ImageSamplerDescriptor {
        address_mode_u: ImageAddressMode::Repeat,
        address_mode_v: ImageAddressMode::Repeat,
        address_mode_w: ImageAddressMode::Repeat,
        mag_filter: ImageFilterMode::Linear,
        min_filter: ImageFilterMode::Linear,
        mipmap_filter: ImageFilterMode::Linear,
        anisotropy_clamp: 8,
        ..default()
    };
    for tex in Tex::ALL {
        let s1 = sampler.clone();
        let color: Handle<Image> = assets
            .load_builder()
            .with_settings(move |settings: &mut ImageLoaderSettings| {
                settings.sampler = ImageSampler::Descriptor(s1.clone());
            })
            .load(format!("textures/{}.png", tex.file()));
        let s2 = sampler.clone();
        let normal: Handle<Image> = assets
            .load_builder()
            .with_settings(move |settings: &mut ImageLoaderSettings| {
                settings.sampler = ImageSampler::Descriptor(s2.clone());
                settings.is_srgb = false; // une carte de relief n'est pas une couleur
            })
            .load(format!("textures/{}_n.png", tex.file()));
        gfx.ids.insert(color.id());
        gfx.ids.insert(normal.id());
        gfx.textures.insert(tex, (color, normal));
    }
}

/// Bevy ne génère pas de mipmaps pour les PNG : sans elles, les textures « scintillent » de loin.
fn build_mipmaps(
    mut events: MessageReader<AssetEvent<Image>>,
    gfx: Res<Gfx>,
    mut images: ResMut<Assets<Image>>,
) {
    for event in events.read() {
        let (AssetEvent::Added { id } | AssetEvent::LoadedWithDependencies { id }) = event else {
            continue;
        };
        if !gfx.ids.contains(id) {
            continue;
        }
        let Some(mut image) = images.get_mut(*id) else { continue };
        add_mipmaps(&mut image);
    }
}

fn add_mipmaps(image: &mut Image) {
    let size = image.texture_descriptor.size;
    if image.texture_descriptor.mip_level_count > 1 || size.depth_or_array_layers != 1 {
        return;
    }
    let (mut w, mut h) = (size.width as usize, size.height as usize);
    let Some(data) = image.data.as_mut() else { return };
    if data.len() != w * h * 4 {
        return; // format inattendu : on laisse tel quel
    }
    let mut levels = 1;
    let mut prev_start = 0;
    while w > 1 && h > 1 {
        let (nw, nh) = (w / 2, h / 2);
        let mut next = Vec::with_capacity(nw * nh * 4);
        for y in 0..nh {
            for x in 0..nw {
                for c in 0..4 {
                    let at = |xx: usize, yy: usize| data[prev_start + (yy * w + xx) * 4 + c] as u32;
                    let sum = at(2 * x, 2 * y) + at(2 * x + 1, 2 * y) + at(2 * x, 2 * y + 1) + at(2 * x + 1, 2 * y + 1);
                    next.push(((sum + 2) / 4) as u8);
                }
            }
        }
        prev_start = data.len();
        data.extend_from_slice(&next);
        w = nw;
        h = nh;
        levels += 1;
    }
    image.texture_descriptor.mip_level_count = levels;
}

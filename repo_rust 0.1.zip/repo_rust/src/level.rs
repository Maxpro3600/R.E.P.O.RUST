//! Génération des niveaux : une grille de pièces reliées par des portes (labyrinthe + boucles),
//! chacune avec son ambiance (entrepôt, bureau, salon, chaufferie) et son mobilier,
//! un camion de départ, des plateformes d'extraction, des objets de valeur et des monstres.

use avian3d::prelude::*;
use bevy::prelude::*;

use crate::common::*;
use crate::enemy::{EnemyKind, spawn_enemy};
use crate::extraction::ExtractionPoint;
use crate::game::{GameState, Run};
use crate::grab::Held;
use crate::interact::Interactable;
use crate::nav::NavGrid;
use crate::player::Player;
use crate::props::{Ctx, Placer, ROOM, Theme, WALL_T, furnish};
use crate::rng::Rng;
use crate::textures::{Gfx, Tex};
use crate::valuables::{ValuableSpec, spawn_valuable};

const WALL_H: f32 = 4.0;
const DOOR_W: f32 = 3.6;
const NAV_CELL: f32 = 0.5;
/// Les objets au sol sont placés dans ±ZONE autour du centre : le mobilier reste contre les murs.
const ZONE: f32 = 3.3;

/// Objets de valeur : (nom, taille, masse, valeur min, valeur max, fragilité, couleur, texture).
const CATALOG: [(&str, Vec3, f32, f32, f32, f32, [f32; 3], Tex); 7] = [
    ("Vase", Vec3::new(0.35, 0.6, 0.35), 3.0, 400.0, 800.0, 1.6, [0.45, 0.65, 0.95], Tex::Tile),
    ("Ordinateur", Vec3::new(0.7, 0.5, 0.6), 8.0, 700.0, 1200.0, 1.2, [0.75, 0.75, 0.8], Tex::Metal),
    ("Tableau", Vec3::new(1.0, 0.8, 0.12), 5.0, 600.0, 1000.0, 1.0, [0.95, 0.75, 0.3], Tex::Wood),
    ("Statuette", Vec3::new(0.3, 0.5, 0.3), 6.0, 800.0, 1500.0, 1.0, [0.85, 0.4, 0.4], Tex::Concrete),
    ("Radio", Vec3::new(0.5, 0.3, 0.3), 4.0, 300.0, 600.0, 1.0, [0.5, 0.65, 0.5], Tex::Metal),
    ("Coffre", Vec3::new(0.8, 0.5, 0.5), 25.0, 1500.0, 2500.0, 0.6, [0.7, 0.5, 0.3], Tex::Wood),
    ("Statue", Vec3::new(0.6, 1.2, 0.6), 40.0, 2000.0, 3500.0, 0.5, [0.9, 0.9, 0.85], Tex::Concrete),
];

#[derive(Component)]
struct Flicker {
    base: f32,
    speed: f32,
    phase: f32,
}

pub struct LevelPlugin;

impl Plugin for LevelPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<NavGrid>()
            .init_resource::<Rng>()
            .insert_resource(ClearColor(Color::srgb(0.01, 0.01, 0.015)))
            .insert_resource(GlobalAmbientLight {
                color: Color::srgb(0.6, 0.65, 0.8),
                brightness: 45.0,
                ..default()
            })
            .add_systems(
                OnEnter(GameState::Playing),
                generate_level.run_if(|run: Res<Run>| run.needs_level),
            )
            .add_systems(OnEnter(GameState::Shop), despawn_level)
            .add_systems(OnEnter(GameState::Menu), despawn_level)
            .add_systems(Update, flicker.run_if(in_state(GameState::Playing)));
    }
}

fn despawn_level(mut commands: Commands, level: Query<Entity, With<LevelEntity>>, mut held: ResMut<Held>) {
    for e in &level {
        commands.entity(e).despawn();
    }
    held.entity = None;
}

fn flicker(time: Res<Time>, mut lights: Query<(&mut PointLight, &Flicker)>) {
    let t = time.elapsed_secs();
    for (mut light, f) in &mut lights {
        let a = (t * f.speed + f.phase).sin() * (t * f.speed * 2.7 + f.phase).sin();
        light.intensity = f.base * if a > 0.6 { 0.08 } else { 1.0 };
    }
}

/// Un côté de pièce : plein, ou avec une porte au milieu (et un linteau au-dessus).
fn wall_side(cx: &mut Ctx, theme: Theme, center: Vec3, along_x: bool, open: bool) {
    let (tex, tint) = theme.wall();
    let y = WALL_H / 2.0;
    if !open {
        let size = if along_x {
            Vec3::new(ROOM + WALL_T, WALL_H, WALL_T)
        } else {
            Vec3::new(WALL_T, WALL_H, ROOM + WALL_T)
        };
        cx.solid(tex, tint, Vec3::new(center.x, y, center.z), size, true);
        return;
    }
    let len = ROOM / 2.0 + WALL_T / 2.0 - DOOR_W / 2.0;
    let offset = DOOR_W / 2.0 + len / 2.0;
    for s in [-1.0, 1.0] {
        let (pos, size) = if along_x {
            (Vec3::new(center.x + s * offset, y, center.z), Vec3::new(len, WALL_H, WALL_T))
        } else {
            (Vec3::new(center.x, y, center.z + s * offset), Vec3::new(WALL_T, WALL_H, len))
        };
        cx.solid(tex, tint, pos, size, true);
    }
    let size = if along_x {
        Vec3::new(DOOR_W, 1.0, WALL_T)
    } else {
        Vec3::new(WALL_T, 1.0, DOOR_W)
    };
    cx.solid(tex, tint, Vec3::new(center.x, 3.5, center.z), size, false);
}

#[allow(clippy::too_many_arguments)]
fn generate_level(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut gfx: ResMut<Gfx>,
    mut run: ResMut<Run>,
    mut rng: ResMut<Rng>,
    existing: Query<Entity, With<LevelEntity>>,
    player: Single<(Entity, &mut Transform, &mut Position, &mut LinearVelocity), With<Player>>,
    mut nav: ResMut<NavGrid>,
    mut held: ResMut<Held>,
) {
    for e in &existing {
        commands.entity(e).despawn();
    }
    held.entity = None;
    run.needs_level = false;
    run.banked = 0.0;
    run.extractions_done = 0;
    let level = run.level;

    // --- Dimensions et labyrinthe de pièces.
    let cols = 3 + ((level / 3) as usize).min(2);
    let rows = 3 + ((level / 4) as usize).min(1);
    let n = cols * rows;
    let room_center = |i: usize| {
        let (x, y) = ((i % cols) as f32, (i / cols) as f32);
        Vec3::new(
            (x - (cols as f32 - 1.0) / 2.0) * ROOM,
            0.0,
            (y - (rows as f32 - 1.0) / 2.0) * ROOM,
        )
    };

    // open_e[i] : porte entre la pièce i et sa voisine de droite ; open_s[i] : avec celle du dessous.
    let mut open_e = vec![false; n];
    let mut open_s = vec![false; n];
    let mut visited = vec![false; n];
    let mut stack = vec![0usize];
    visited[0] = true;
    while let Some(&cur) = stack.last() {
        let (x, y) = (cur % cols, cur / cols);
        let mut options = Vec::new();
        if x + 1 < cols && !visited[cur + 1] {
            options.push(cur + 1);
        }
        if x > 0 && !visited[cur - 1] {
            options.push(cur - 1);
        }
        if y + 1 < rows && !visited[cur + cols] {
            options.push(cur + cols);
        }
        if y > 0 && !visited[cur - cols] {
            options.push(cur - cols);
        }
        if options.is_empty() {
            stack.pop();
            continue;
        }
        let next = options[rng.index(options.len())];
        match next as isize - cur as isize {
            1 => open_e[cur] = true,
            -1 => open_e[next] = true,
            d if d == cols as isize => open_s[cur] = true,
            _ => open_s[next] = true,
        }
        visited[next] = true;
        stack.push(next);
    }
    // Quelques portes en plus pour créer des boucles (sinon un seul chemin entre deux pièces).
    for i in 0..n {
        if i % cols + 1 < cols && !open_e[i] && rng.chance(0.3) {
            open_e[i] = true;
        }
        if i / cols + 1 < rows && !open_s[i] && rng.chance(0.3) {
            open_s[i] = true;
        }
    }

    // --- Navigation.
    let half = Vec2::new(cols as f32, rows as f32) * ROOM / 2.0 + Vec2::splat(2.0);
    *nav = NavGrid::new(-half, half, NAV_CELL);
    nav.room_centers = (0..n).map(room_center).collect();

    let mut cx = Ctx {
        commands: &mut commands,
        meshes: &mut meshes,
        materials: &mut materials,
        gfx: &mut gfx,
        nav: &mut nav,
    };

    // --- Ambiance de chaque pièce (celle de départ est toujours un entrepôt).
    let themes: Vec<Theme> = (0..n)
        .map(|i| if i == 0 { Theme::Warehouse } else { Theme::random(&mut rng) })
        .collect();

    // --- Sols (un par pièce), plafond, murs.
    for i in 0..n {
        let (tex, tint) = themes[i].floor();
        let c = room_center(i);
        cx.solid(tex, tint, Vec3::new(c.x, -0.2, c.z), Vec3::new(ROOM, 0.4, ROOM), false);
    }
    let slab = Vec3::new(cols as f32 * ROOM + 4.0, 0.4, rows as f32 * ROOM + 4.0);
    cx.solid(Tex::Ceiling, Color::srgb(0.85, 0.85, 0.82), Vec3::new(0.0, WALL_H + 0.2, 0.0), slab, false);

    let (gx, gz) = (cols as f32 * ROOM / 2.0, rows as f32 * ROOM / 2.0);
    for k in 0..=cols {
        for y in 0..rows {
            let open = k >= 1 && k < cols && open_e[y * cols + k - 1];
            let theme = themes[y * cols + k.min(cols - 1)];
            let center = Vec3::new(k as f32 * ROOM - gx, 0.0, room_center(y * cols).z);
            wall_side(&mut cx, theme, center, false, open);
        }
    }
    for j in 0..=rows {
        for x in 0..cols {
            let open = j >= 1 && j < rows && open_s[(j - 1) * cols + x];
            let theme = themes[j.min(rows - 1) * cols + x];
            let center = Vec3::new(room_center(x).x, 0.0, j as f32 * ROOM - gz);
            wall_side(&mut cx, theme, center, true, open);
        }
    }

    // --- Lumières : une par pièce ; certaines faibles, certaines clignotantes.
    let fixture_mesh = cx.gfx.shape(cx.meshes, "fixture", || Cuboid::new(0.8, 0.1, 0.8).into());
    for i in 0..n {
        let c = room_center(i);
        let dim = i != 0 && rng.chance(0.25);
        let base = if dim { 25_000.0 } else { rng.range(110_000.0, 240_000.0) };
        let tint = if rng.chance(0.3) { Color::srgb(0.75, 0.85, 1.0) } else { Color::srgb(1.0, 0.9, 0.75) };
        let mut light = cx.commands.spawn((
            LevelEntity,
            PointLight { intensity: base, range: 18.0, color: tint, ..default() },
            Transform::from_xyz(c.x, 3.4, c.z),
        ));
        if i != 0 && rng.chance(0.3) {
            light.insert(Flicker { base, speed: rng.range(3.0, 9.0), phase: rng.range(0.0, 6.0) });
        }
        // Le luminaire visible au plafond.
        let fixture = cx.materials.add(StandardMaterial {
            base_color: tint,
            emissive: tint.to_linear() * if dim { 0.4 } else { 3.0 },
            ..default()
        });
        cx.commands.spawn((
            LevelEntity,
            Mesh3d(fixture_mesh.clone()),
            MeshMaterial3d(fixture),
            Transform::from_xyz(c.x, WALL_H - 0.05, c.z),
        ));
    }

    let mut placers: Vec<Placer> = (0..n).map(|_| Placer::default()).collect();

    // --- Pièce de départ : camion + terminal. Le joueur y apparaît.
    let start = room_center(0);
    let truck_pos = Vec3::new(start.x, 1.3, start.z - ROOM / 2.0 + 1.6);
    cx.solid(Tex::Metal, Color::srgb(0.4, 0.5, 0.65), truck_pos, Vec3::new(5.0, 2.6, 2.4), true);
    placers[0].reserve(Vec2::new(truck_pos.x, truck_pos.z), Vec2::new(2.5, 1.2));
    let terminal_pos = Vec3::new(start.x + 3.9, 0.55, start.z - ROOM / 2.0 + 0.8);
    let terminal = cx.solid(Tex::Metal, Color::srgb(0.95, 0.65, 0.2), terminal_pos, Vec3::new(0.9, 1.1, 0.5), true);
    cx.commands.entity(terminal).insert((Interactable::Truck, Name::new("Terminal du camion")));
    placers[0].reserve(Vec2::new(terminal_pos.x, terminal_pos.z), Vec2::new(0.5, 0.3));
    let screen = cx.materials.add(StandardMaterial {
        base_color: Color::BLACK,
        emissive: LinearRgba::new(2.0, 0.9, 0.0, 1.0),
        ..default()
    });
    let screen_mesh = cx.gfx.shape(cx.meshes, "terminal_screen", || Cuboid::new(0.7, 0.4, 0.02).into());
    cx.commands.spawn((
        LevelEntity,
        Mesh3d(screen_mesh),
        MeshMaterial3d(screen),
        Transform::from_xyz(terminal_pos.x, 0.95, terminal_pos.z + 0.26),
    ));

    // Le joueur est interpolé par la physique : écrire seulement son Transform serait ignoré
    // (la Position physique fait foi). On écrit les deux, et on réinitialise l'interpolation
    // pour que la caméra ne « glisse » pas depuis l'ancien emplacement.
    let (player_entity, mut player_tf, mut player_pos, mut player_vel) = player.into_inner();
    let spawn = Vec3::new(start.x, 1.0, start.z + 1.5);
    player_tf.translation = spawn;
    player_pos.0 = spawn;
    player_vel.0 = Vec3::ZERO;
    cx.commands
        .entity(player_entity)
        .remove::<TransformInterpolation>()
        .insert(TransformInterpolation);

    // --- Plateformes d'extraction : dans les pièces les plus éloignées du départ.
    let manhattan = |i: usize| (i % cols) + (i / cols);
    let count = (1 + (level >= 4) as usize + (level >= 7) as usize).min(n - 1);
    let per_point = ((Run::goal_for(level) / count as f32) / 50.0).round() * 50.0;
    run.goal = per_point * count as f32;
    run.extractions_total = count as u32;

    let mut candidates: Vec<usize> = (1..n).collect();
    rng.shuffle(&mut candidates);
    candidates.sort_by_key(|&i| std::cmp::Reverse(manhattan(i)));
    let pad_mesh = cx.gfx.shape(cx.meshes, "pad", || Cuboid::new(3.0, 0.05, 3.0).into());
    let console_screen = cx.gfx.shape(cx.meshes, "console_screen", || Cuboid::new(0.4, 0.25, 0.02).into());
    for (index, &i) in candidates.iter().take(count).enumerate() {
        let c = room_center(i);
        let pad = cx.materials.add(StandardMaterial {
            base_color: Color::srgb(0.1, 0.9, 0.3),
            emissive: LinearRgba::new(0.0, 0.7, 0.2, 1.0),
            ..default()
        });
        cx.commands.spawn((
            LevelEntity,
            Name::new("Plateforme d'extraction"),
            ExtractionPoint::new(index, per_point, Vec3::new(c.x, 1.0, c.z), Vec3::new(1.5, 1.0, 1.5), pad.clone()),
            Mesh3d(pad_mesh.clone()),
            MeshMaterial3d(pad),
            Transform::from_xyz(c.x, 0.03, c.z),
        ));
        let console_pos = Vec3::new(c.x + 2.4, 0.55, c.z);
        let console = cx.solid(Tex::Metal, Color::srgb(0.3, 0.55, 0.4), console_pos, Vec3::new(0.6, 1.1, 0.6), true);
        cx.commands.entity(console).insert(Name::new("Console d'extraction"));
        let glow = cx.materials.add(StandardMaterial {
            base_color: Color::BLACK,
            emissive: LinearRgba::new(0.0, 1.5, 0.4, 1.0),
            ..default()
        });
        cx.commands.spawn((
            LevelEntity,
            Mesh3d(console_screen.clone()),
            MeshMaterial3d(glow),
            Transform::from_xyz(console_pos.x - 0.31, 0.95, console_pos.z)
                .with_rotation(Quat::from_rotation_y(-std::f32::consts::FRAC_PI_2)),
        ));
        placers[i].reserve(Vec2::new(c.x, c.z), Vec2::splat(1.7));
        placers[i].reserve(Vec2::new(console_pos.x, console_pos.z), Vec2::splat(0.4));
    }

    // --- Mobilier de chaque pièce.
    let mut slots: Vec<Vec<Vec3>> = Vec::with_capacity(n);
    for i in 0..n {
        let s = furnish(&mut cx, &mut rng, themes[i], room_center(i), &mut placers[i], i != 0);
        slots.push(s);
    }

    // --- Objets de valeur : assez pour dépasser largement l'objectif. Les petits finissent
    // souvent sur une étagère, comme dans le vrai jeu.
    let target = run.goal * 1.8;
    let (mut sum, mut spawned) = (0.0, 0);
    while (sum < target || spawned < n) && spawned < 45 {
        let (name, size, mass, vmin, vmax, fragility, color, tex) = CATALOG[rng.index(CATALOG.len())];
        let value = (rng.range(vmin, vmax) / 10.0).round() * 10.0;
        let room = 1 + rng.index(n - 1);
        let c = room_center(room);
        let on_shelf = size.y <= 0.6 && mass <= 10.0 && !slots[room].is_empty() && rng.chance(0.6);
        let pos = if on_shelf {
            let k = rng.index(slots[room].len());
            slots[room].swap_remove(k) + Vec3::Y * (size.y / 2.0 + 0.03)
        } else {
            Vec3::new(c.x + rng.range(-ZONE, ZONE), size.y / 2.0 + 0.05, c.z + rng.range(-ZONE, ZONE))
        };
        spawn_valuable(
            cx.commands,
            cx.meshes,
            cx.materials,
            cx.gfx,
            ValuableSpec {
                name,
                size,
                mass,
                value,
                fragility,
                color: Color::srgb(color[0], color[1], color[2]),
                tex,
            },
            pos,
        );
        sum += value;
        spawned += 1;
    }

    // --- Cartons sur les étagères restantes, caisses au sol.
    for room_slots in &slots {
        for slot in room_slots {
            if rng.chance(0.4) {
                let s = rng.range(0.22, 0.38);
                let tint = [Color::srgb(0.85, 0.72, 0.55), Color::srgb(0.75, 0.65, 0.5), Color::srgb(0.9, 0.8, 0.65)][rng.index(3)];
                cx.crate_box("Carton", *slot + Vec3::Y * (s / 2.0 + 0.02), s, 1.0, tint);
            }
        }
    }
    for i in 1..n {
        let c = room_center(i);
        for _ in 0..rng.index(3) {
            let s = rng.range(0.6, 1.0);
            let tint = [Color::srgb(0.9, 0.78, 0.6), Color::srgb(0.8, 0.68, 0.52), Color::srgb(1.0, 0.88, 0.7)][rng.index(3)];
            let pos = Vec3::new(c.x + rng.range(-ZONE, ZONE), s / 2.0 + 0.05, c.z + rng.range(-ZONE, ZONE));
            cx.crate_box("Caisse", pos, s, s * s * s * 15.0, tint);
        }
    }

    // --- Monstres : de plus en plus nombreux, jamais dans la pièce de départ.
    let far: Vec<usize> = (1..n).filter(|&i| manhattan(i) >= 2).collect();
    let pool = if far.is_empty() { (1..n).collect() } else { far };
    let gnomes = (1 + level / 2).min(6);
    let brutes = ((level.max(1) - 1) / 3).min(3);
    for (kind, how_many) in [(EnemyKind::Gnome, gnomes), (EnemyKind::Brute, brutes)] {
        for _ in 0..how_many {
            let c = room_center(pool[rng.index(pool.len())]);
            let pos = Vec3::new(c.x + rng.range(-3.0, 3.0), 0.1, c.z + rng.range(-3.0, 3.0));
            let voice = rng.range(3.0, 12.0);
            spawn_enemy(cx.commands, cx.meshes, cx.materials, kind, pos, voice);
        }
    }
}

//! Plateformes d'extraction : quand le quota de la plateforme est atteint, l'extraction
//! se lance toute seule (compte à rebours bruyant), puis le butin est encaissé.

use bevy::prelude::*;

use crate::common::*;
use crate::game::{GameState, Run};
use crate::valuables::Valuable;

/// Durée du compte à rebours une fois le quota atteint.
const EXTRACT_TIME: f32 = 4.0;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum PointState {
    /// Attend que le quota soit atteint.
    Waiting,
    /// Extraction en cours : temps restant.
    Extracting(f32),
    Done,
}

#[derive(Component)]
pub struct ExtractionPoint {
    pub index: usize,
    /// Valeur à déposer sur la plateforme pour lancer l'extraction.
    pub goal: f32,
    /// Valeur actuellement posée sur la plateforme.
    pub in_zone: f32,
    pub state: PointState,
    center: Vec3,
    half_extents: Vec3,
    pad: Handle<StandardMaterial>,
    shown: u8,
    beep: f32,
}

impl ExtractionPoint {
    pub fn new(index: usize, goal: f32, center: Vec3, half_extents: Vec3, pad: Handle<StandardMaterial>) -> Self {
        Self {
            index,
            goal,
            in_zone: 0.0,
            state: PointState::Waiting,
            center,
            half_extents,
            pad,
            shown: 255,
            beep: 0.0,
        }
    }

    fn contains(&self, p: Vec3) -> bool {
        let d = (p - self.center).abs();
        d.x <= self.half_extents.x && d.y <= self.half_extents.y && d.z <= self.half_extents.z
    }
}

pub struct ExtractionPlugin;

impl Plugin for ExtractionPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, update_extraction.run_if(in_state(GameState::Playing)));
    }
}

#[allow(clippy::too_many_arguments)]
fn update_extraction(
    time: Res<Time>,
    mut commands: Commands,
    mut points: Query<&mut ExtractionPoint>,
    valuables: Query<(Entity, &Valuable, &Transform)>,
    mut run: ResMut<Run>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut sfx: MessageWriter<PlaySfx>,
    mut noise: MessageWriter<Noise>,
    mut toasts: MessageWriter<Toast>,
) {
    let dt = time.delta_secs();
    let t = time.elapsed_secs();
    for mut point in &mut points {
        if point.state == PointState::Done {
            continue;
        }
        // Ce qui est posé sur la plateforme.
        let (mut sum, mut inside) = (0.0, Vec::new());
        for (entity, valuable, transform) in &valuables {
            if point.contains(transform.translation) {
                sum += valuable.value;
                inside.push(entity);
            }
        }
        point.in_zone = sum;
        let pos = point.center;
        let name = point.index + 1;

        match point.state {
            PointState::Waiting => {
                if sum >= point.goal {
                    point.state = PointState::Extracting(EXTRACT_TIME);
                    point.beep = 0.0;
                    toasts.write(Toast(format!(
                        "Plateforme {name} : quota atteint, extraction dans {EXTRACT_TIME:.0} s. Tiens bon !"
                    )));
                }
            }
            PointState::Extracting(left) => {
                if sum < point.goal {
                    // Un objet a été retiré (ou détruit) : on annule.
                    point.state = PointState::Waiting;
                    sfx.write(PlaySfx::at(Sfx::Error, pos, 0.7));
                    toasts.write(Toast(format!("Plateforme {name} : extraction interrompue (quota plus atteint).")));
                } else if left <= 0.0 {
                    for entity in inside {
                        commands.entity(entity).despawn();
                    }
                    run.banked += sum;
                    run.extractions_done += 1;
                    point.state = PointState::Done;
                    sfx.write(PlaySfx::at(Sfx::Ding, pos, 1.0));
                    noise.write(Noise { pos, radius: 30.0 });
                    toasts.write(Toast(format!("Plateforme {name} extraite : +{sum:.0} $")));
                } else {
                    point.state = PointState::Extracting(left - dt);
                    // Un bip par seconde, et chaque bip s'entend de loin.
                    point.beep -= dt;
                    if point.beep <= 0.0 {
                        point.beep = 1.0;
                        sfx.write(PlaySfx::at(Sfx::Beep, pos, 0.9));
                        noise.write(Noise { pos, radius: 25.0 });
                    }
                }
            }
            PointState::Done => {}
        }

        // Couleur de la plateforme : vert (attente), orange qui pulse (en cours), éteinte (finie).
        let code = match point.state {
            PointState::Waiting => 0,
            PointState::Extracting(_) => 1,
            PointState::Done => 2,
        };
        if code == 1 || code != point.shown {
            point.shown = code;
            if let Some(mut material) = materials.get_mut(&point.pad) {
                match code {
                    0 => {
                        material.base_color = Color::srgb(0.1, 0.9, 0.3);
                        material.emissive = LinearRgba::new(0.0, 0.7, 0.2, 1.0);
                    }
                    1 => {
                        let pulse = 1.5 + (t * 8.0).sin();
                        material.base_color = Color::srgb(1.0, 0.55, 0.1);
                        material.emissive = LinearRgba::new(2.0 * pulse, 0.8 * pulse, 0.0, 1.0);
                    }
                    _ => {
                        material.base_color = Color::srgb(0.2, 0.2, 0.22);
                        material.emissive = LinearRgba::BLACK;
                    }
                }
            }
        }
    }
}

# R.E.P.O. en Rust — version jouable (solo)

Clone de R.E.P.O. : coop d'horreur à la première personne, avec de la vraie physique.
Construit avec **Bevy 0.20** (moteur) et **Avian 0.8** (physique).
Les versions sont figées par `Cargo.lock` : ne lance pas `cargo update` sans raison,
Bevy change d'API à chaque version majeure.

## Lancer sous Windows

1. Installe Rust : https://rustup.rs (télécharge `rustup-init.exe`).
   Il te demandera d'installer les **Outils de build C++ de Visual Studio**
   (« Desktop development with C++ ») : accepte, c'est obligatoire.
2. Ouvre un terminal dans ce dossier, puis :

```
cargo run --release
```

La première compilation est longue (10 à 20 minutes sur un portable) ; les
suivantes ne recompilent que ton code. Utilise `--release` pour juger les
performances réelles.

**Pour développer** (modifier le code et relancer souvent) : `cargo run --features dev`
recompile beaucoup plus vite (liaison dynamique de Bevy). Ne l'utilise pas pour jouer.

### Pourquoi ça démarre vite

- Le **menu d'accueil** s'affiche tout de suite : le niveau n'est généré qu'au clic sur « Jouer ».
- Bevy est réduit à ce dont le jeu a besoin (pas de glTF, animation, manettes, scènes...).
- Maillages et matériaux sont **mis en cache** : un niveau compte ~70 maillages et ~70 matériaux
  au lieu d'un par objet, et les textures n'ont aucun fichier `.meta` à chercher.
- Pas de LTO en release : la compilation est nettement plus courte pour un gain d'exécution négligeable.

## Commandes

| Action | Touche |
|---|---|
| Pause / reprise | Échap |
| Menu d'accueil : jouer | Entrée ou clic sur « Jouer » |
| Se déplacer | WASD (= ZQSD sur AZERTY, sans rien configurer) |
| Courir / Sauter / S'accroupir | Maj gauche / Espace / Ctrl ou C |
| Lampe torche | F |
| Attraper un objet (maintenu) | Clic droit |
| Distance de l'objet tenu | Molette |
| Lancer l'objet tenu | Clic gauche |
| Terminal du camion | E |
| Pack de soin | H |
| Boutique : acheter / continuer | 1 à 5 / Entrée |
| Après la mort : recommencer | R |

## Boucle de jeu (inspirée du vrai jeu)

1. Tu arrives dans la pièce du **camion**. Le niveau est généré au hasard : pièces reliées par des
   portes, chacune avec son ambiance (entrepôt, bureau, salon, chaufferie) et son mobilier
   (étagères, bureaux, casiers, tonneaux, canapés, tuyaux...). Quelques pièces sont sombres ou clignotent.
2. Trouve des **objets de valeur** (certains sont posés sur des étagères) et traîne-les jusqu'à une
   **plateforme d'extraction** (verte). Chaque choc leur fait perdre de la valeur (ils rougissent).
3. Chaque plateforme a son **quota**. Dès qu'il est atteint, **l'extraction se lance toute seule** :
   compte à rebours de 4 secondes, avec des bips qui s'entendent de loin (les monstres viennent !).
   Si tu retires un objet et que le quota n'est plus atteint, l'extraction s'interrompt.
4. L'écran affiche en haut à gauche le nombre d'**extractions restantes** et l'avancement de chaque plateforme.
5. Toutes les extractions faites : retourne au **terminal du camion** (E) pour finir le niveau.
6. **Station-service** : dépense ton surplus (santé, endurance, force, vitesse, packs de soin).
   La santé ne remonte pas toute seule.
7. Niveau suivant : plus grand, objectif plus élevé, plus de monstres, plus de plateformes (jusqu'à 3).
   Si tu meurs, la partie est perdue (comme la sauvegarde dans le vrai jeu).

**Monstres** : ils patrouillent, **entendent** tes bruits (pas, course, saut, chocs, extraction)
et te poursuivent s'ils te voient. Accroupi, tu es presque silencieux. Ce sont des objets
physiques : un objet lourd lancé dessus leur fait mal. Un monstre abattu laisse un orbe de valeur.
Deux types pour l'instant : Gnome (niveau de danger 1) et Brute (niveau 2, dès le niveau 4).

## Sons

22 effets : pas, saut, chocs légers et lourds, verre brisé, attraper/lancer, lampe, extraction,
boutique, douleur, mort, battements de cœur à faible santé, grognements et attaques des monstres,
ambiance en boucle. Les sons importants sont **spatialisés** (on entend d'où vient un monstre).
Ils sont tous synthétisés par `tools/gen_sounds.py` (nécessite `numpy`) : aucun son du vrai jeu.
Pour les changer, modifie le script puis relance-le, ou remplace les `.wav` de `assets/sounds/`.

## Textures

8 matériaux (béton, plâtre, brique, carrelage, bois, métal, moquette, dalles de plafond), chacun avec
sa **carte de relief** : le relief réagit à ta lampe torche. Les textures gardent la même échelle
sur un mur de 12 m comme sur une caisse, avec mipmaps et filtrage anisotrope (pas de scintillement
au loin). Elles sont générées par `tools/gen_textures.py` (nécessite `numpy` et `Pillow`) :
100 % originales, rien n'est tiré du vrai jeu. Tu peux remplacer n'importe quel `.png` de
`assets/textures/` par une image de ton choix (256x256 raccordable, avec son `_n.png` de relief).

## Organisation du code

Un plugin Bevy par fonctionnalité, dans `src/` :

| Fichier | Rôle |
|---|---|
| `game.rs` | états (Playing / Shop / Dead) et progression |
| `level.rs` | génération des niveaux, lumières, camion, plateformes |
| `props.rs` | mobilier, ambiances des pièces, placement |
| `textures.rs` | textures, matériaux et maillages mis en cache |
| `extraction.rs` | plateformes d'extraction automatiques |
| `menu.rs` | menu d'accueil, pause, souris |
| `nav.rs` | grille de navigation et chemin A* des monstres |
| `player.rs` | déplacement, santé, endurance, lampe |
| `grab.rs` | attraper, déplacer, lancer |
| `impact.rs`, `valuables.rs` | détection des chocs, valeur des objets |
| `enemy.rs` | monstres (vue, ouïe, poursuite, attaque) |
| `combat.rs` | dégâts, mort, flash rouge |
| `interact.rs` | console d'extraction, terminal du camion |
| `audio.rs`, `shop.rs`, `hud.rs` | son, boutique, interface |

## Ce qu'il manque encore par rapport au vrai jeu

Multijoueur et chat vocal de proximité, le chariot (C.A.R.T.), la tête du joueur mort qu'on
rapporte pour le réanimer, armes / grenades / drones / outils, la vingtaine d'autres monstres,
des modules de niveaux variés, une boutique physique, la mini-carte, les cosmétiques.
Aucune ressource du jeu original n'est utilisée : formes simples, textures et sons générés.

## Si le jeu rame sur ton portable

Dans `src/player.rs`, mets `shadow_maps_enabled: false` sur la lampe torche (c'est la seule
lumière qui projette des ombres). Le MSAA est déjà désactivé et les lumières des pièces
n'ont pas d'ombres.
